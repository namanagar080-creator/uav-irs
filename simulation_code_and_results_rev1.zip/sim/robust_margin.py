"""M1 with a planning margin on the rate floor under CSI error / reconfiguration overhead."""
import json, pickle, numpy as np, warnings
warnings.filterwarnings('ignore')
import model as md, m1
from model import P, BS_POS
from robust import overhead
cmp_ = pickle.load(open('out/compare.pkl', 'rb'))
out = {}
for marg in (0.1, 0.25, 0.5):
    out[str(marg)] = {}
    for kind, grid in (('sigma', [0, 2, 4, 6, 8]), ('tau', [0.0, 0.02, 0.05, 0.1])):
        for g in grid:
            v = []
            for r in cmp_:
                u, q, s = r['users'], r['q_M1'], r['seed']
                for d in range(5 if kind == 'sigma' and g > 0 else 1):
                    rng = np.random.default_rng(1000 * s + d)
                    G = md.gain(q, BS_POS[0], u, P['H'])
                    sig = g if kind == 'sigma' else 0; tau = g if kind == 'tau' else 0
                    rho = m1.schedule_lp(G * 10 ** (sig * rng.standard_normal(G.shape) / 10), P['Pmax'], rmin_bits=P['Rmin'] * (1 + marg))
                    m = md.metrics_single(q, u, overhead(rho, tau), P['Pmax'])
                    v.append((m['EE'], m['bits_k'].min() >= 0.995 * P['Rmin']))
            out[str(marg)]['%s_%s' % (kind, g)] = dict(EE=float(np.mean([x[0] for x in v])), feas=float(np.mean([x[1] for x in v])))
        print(marg, {k: (round(x['EE']), round(x['feas'], 2)) for k, x in out[str(marg)].items()}, flush=True)
json.dump(out, open('out/robust_margin.json', 'w'), indent=1)
