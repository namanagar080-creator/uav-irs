import re, openpyxl
XL = '/root/.claude/uploads/4601cdbc-6b06-5104-a4a4-e73f870f1cb8/2bb05b5c-P16T8EnergyAware_IRS_UAV_Communication_References.xlsx'
KEEP = {'UAV', 'IRS', 'RIS', 'IoT', 'OFDMA', 'MEC', 'SWIPT', 'ISAC', 'CSI', 'LAP', 'AI', 'EE', '5G', '6G', '3D', 'IRSs', 'IRS-UAV', 'UAVs', 'MEC', 'II', 'I'}


def sentence_case(t):
    words = t.split(' ')
    out = []
    cap_next = True
    for w in words:
        parts = w.split('-')
        newp = []
        for j, pt in enumerate(parts):
            core = re.sub(r'[^\w/]', '', pt)
            if core in KEEP or (core.isupper() and len(core) > 1) or any(ch.isdigit() for ch in core):
                newp.append(pt)
            elif cap_next and j == 0:
                newp.append(pt[:1].upper() + pt[1:].lower())
            else:
                newp.append(pt.lower())
        out.append('-'.join(newp))
        cap_next = w.endswith(':')
    return ' '.join(out)


def venue_fmt(v):
    v = v.strip()
    m = re.match(r'^(.*?) (\d+)\((\d+)\), ([\d\-]+)$', v)
    if m: return '*%s*, %s(%s): %s' % (m.group(1), m.group(2), m.group(3), m.group(4))
    m = re.match(r'^(.*?) (\d+), ([\d\-]+)$', v)
    if m: return '*%s*, %s: %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'^(.*?) (\d+)$', v)
    if m: return '*%s*, %s' % (m.group(1), m.group(2))
    return '*%s*' % v


def load():
    ws = openpyxl.load_workbook(XL)['References']
    refs = {}
    for r in ws.iter_rows(min_row=2, values_only=True):
        n, grp, au, ti, ve, yr, doi, note = r[:8]
        if n is None: continue
        if n == 20:
            au = 'Hu, H., Zhao, S., Huang, Y., Yu, K., Kang, Q., Cheng, G.'
        if n == 21:
            au = 'Wang, P., Tang, H., Li, D., Zhang, Y., Chen, X.'
        if n == 15:
            vtxt = 'In *Proceedings of the IEEE International Conference on Communications (ICC) Workshops*, 2020'
        elif n == 21:
            vtxt = '*Vehicular Communications*, 55: 100953'; doi = '10.1016/j.vehcom.2025.100953'
        elif n == 20:
            vtxt = '*Scientific Reports*, 15: 9124'
        else:
            vtxt = venue_fmt(ve)
        s = '%s (%s). %s. %s.' % (au, yr, sentence_case(ti), vtxt)
        if doi and doi.startswith('10.'):
            s += ' https://doi.org/%s' % doi
        refs[n] = dict(text=s, group=grp, year=yr, note=note)
    return refs


if __name__ == '__main__':
    for k, v in load().items(): print(k, v['text'])
