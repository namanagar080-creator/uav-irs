import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8})
NAVY='#1F3864'; BLUE='#2F5597'; GREY='#7F7F7F'; ORG='#C55A11'; GRN='#548235'
fig, ax = plt.subplots(figsize=(7.4, 4.3), dpi=300)
ax.set_xlim(0,100); ax.set_ylim(0,54); ax.axis('off')
def box(x,y,w,h,txt,fc='#DEEAF6',ec=NAVY,fs=7.2,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25,rounding_size=0.8',fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs,fontweight='bold' if bold else 'normal',color='#1a1a1a')
def arr(x1,y1,x2,y2,c=NAVY,ls='-',rad=0.0):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=8,color=c,lw=0.9,ls=ls,connectionstyle=f'arc3,rad={rad}'))
# ---- left panel: system
ax.text(1,52,'(a) System model',fontsize=8.5,fontweight='bold',color=NAVY)
ax.add_patch(Rectangle((1,3),44,44,fc='#F7F7F7',ec=GREY,lw=0.6))
# BS
ax.plot([6,6],[6,16],color=NAVY,lw=2); ax.plot([4,8],[16,16],color=NAVY,lw=2); ax.text(6,4.2,'Ground BS',ha='center',fontsize=6.6,color=NAVY)
# UAV+IRS
ax.add_patch(Rectangle((22,36),9,1.8,fc=ORG,ec='k',lw=0.6)); ax.add_patch(Circle((20.5,38.5),1.7,fc='none',ec='k',lw=0.6)); ax.add_patch(Circle((32.5,38.5),1.7,fc='none',ec='k',lw=0.6))
ax.add_patch(Rectangle((23.5,33),6,2.4,fc=BLUE,ec='k',lw=0.6)); ax.text(3,36,'UAV-mounted IRS\n(M elements,\nb-bit phases)',ha='left',va='center',fontsize=6.2,color=BLUE)
# users
us=[(19,8),(29,12),(40,7),(42.5,19)]
for i,(x,y) in enumerate(us):
    ax.plot(x,y,'o',color=GRN,ms=5); ax.text(x,y-3.0,f'User {i+1}',ha='center',fontsize=6.2,color=GRN)
arr(8.2,15.5,24,33.6,c=NAVY); ax.text(10,27,'BS→IRS\n(LoS)',fontsize=6.3,color=NAVY)
for (x,y) in us[:4]:
    arr(27,32.7,x,y+1.2,c=ORG,ls='--')
ax.text(36.5,28,'IRS→user\n(LoS prob.)',fontsize=5.8,color=ORG,ha='left')
ax.plot([8.3,17],[10,8.4],color=GREY,lw=0.8,ls=':'); ax.text(8.5,12.0,'direct link\nblocked',fontsize=5.8,color=GREY)
ax.text(23,43.5,'Rotary-wing power $P_{prop}(V)$ + IRS circuit $MP_e$',fontsize=6.4,ha='center',color='#333')
# ---- right panel: algorithms
ax.text(49,52,'(b) Proposed methodologies',fontsize=8.5,fontweight='bold',color=NAVY)
box(49,40,24,9,'M1: alternating optimisation\n(1) IRS phases (closed form)\n(2) time-share LP\n(3) trajectory: SCA + Dinkelbach',fc='#DEEAF6',fs=5.9)
arr(60.5,40,60.5,36.5)
box(49,28.5,24,7.5,'Updated trajectory $\\mathbf{q}$,\nschedule $\\rho$, phases $\\theta$\n(repeat until EE converges)',fc='#FFFFFF',fs=5.9)
arr(49,32,49,44.5,rad=-0.45)  # loop
box(76,40,23,9,'M2: PPO agent (BC warm start)\nstate: position, battery,\ndemand, CSI\naction: velocity, TX power,\nIRS user-share softmax',fc='#FBE5D6',ec=ORG,fs=5.6)
box(76,28.5,23,9,'Safety shield (return-to-depot)\nbattery budget\nreward = bits − λ·energy',fc='#FFFFFF',ec=ORG,fs=5.7)
arr(87.5,40,87.5,37.6,c=ORG)
box(49,12,50,12.5,'M3: multi-UAV cooperative scheduling (U co-channel UAV-IRS)\nper-slot joint modes (who serves whom / idle) → time-sharing LP\n= joint user association + interference coordination\nper-UAV trajectory refinement with the M1 SCA step',fc='#E2EFDA',ec=GRN,fs=5.9)
arr(60.5,28.5,60.5,24.8,c=GRN); arr(87.5,28.5,87.5,24.8,c=GRN)
box(49,3,50,6.3,'Metrics: energy, EE (bit/J), sum/min rate, outage,\ncoverage, endurance, trajectory length, Jain index',fc='#F2F2F2',ec=GREY,fs=5.9)
arr(74,12,74,9.7,c=GREY)
fig.savefig('figs/fig1_architecture.png',bbox_inches='tight',dpi=300)
