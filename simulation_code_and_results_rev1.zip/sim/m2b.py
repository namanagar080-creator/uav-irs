"""M2 pipeline: (1) behaviour-cloning warm start from M1 expert trajectories on training layouts,
(2) PPO fine-tuning with battery constraint / demand penalties, (3) evaluation on held-out layouts."""
import sys, pickle, json, numpy as np, torch, torch.nn as nn, warnings
warnings.filterwarnings('ignore')
import model as md, m2
from model import P, DEPOT
from m2 import Env, AC, K, OBS, ACT


def expert_data(experts):
    n = len(experts); N = P['N']
    env = Env(n, np.random.default_rng(0)); env.reset()
    env.users = np.stack([e['users'] for e in experts])
    O = np.zeros((N, n, OBS), np.float32); A = np.zeros((N, n, ACT), np.float32); R = np.zeros((N, n), np.float32)
    o = env.obs()
    for t in range(N):
        a = np.zeros((n, ACT))
        for i, e in enumerate(experts):
            prev = DEPOT if t == 0 else e['q'][t - 1]
            v = (e['q'][t] - prev) / P['delta']
            a[i, 0:2] = np.arctanh(np.clip(v / P['Vmax'], -0.98, 0.98))
            a[i, 2] = 4.0
            a[i, 3:] = np.log(e['rho'][t] + 1e-3)
        O[t] = o; A[t] = a
        o, r, d, _ = env.step(a); R[t] = r
    G = np.zeros_like(R); run = 0
    for t in reversed(range(N)):
        run = R[t] + 0.995 * run; G[t] = run
    return O.reshape(-1, OBS), A.reshape(-1, ACT), G.reshape(-1), env


def bc(net, O, A, G, epochs=400, seed=0):
    torch.manual_seed(seed)
    O, A, G = torch.as_tensor(O), torch.as_tensor(A), torch.as_tensor(G)
    n = len(O); perm = torch.randperm(n); nv = n // 10
    va, tr = perm[:nv], perm[nv:]
    opt = torch.optim.Adam(list(net.pi.parameters()) + list(net.v.parameters()), lr=1e-3)
    mu, sd = G.mean(), G.std() + 1e-6
    for ep in range(epochs):
        idx = tr[torch.randperm(len(tr))]
        for s in range(0, len(idx), 512):
            b = idx[s:s + 512]
            lp = ((net.pi(O[b]) - A[b]) ** 2)
            lp = lp.mean()
            lv = ((net.v(O[b]).squeeze(1) - (G[b] - mu) / sd) ** 2).mean()
            opt.zero_grad(); (lp + lv).backward(); opt.step()
        if ep % 100 == 0 or ep == epochs - 1:
            with torch.no_grad():
                print('BC ep %d train %.4f val %.4f' % (ep, ((net.pi(O[tr]) - A[tr]) ** 2).mean(), ((net.pi(O[va]) - A[va]) ** 2).mean()), flush=True)
    with torch.no_grad():                       # de-standardise the critic output
        net.v[-1].weight.mul_(sd); net.v[-1].bias.mul_(sd).add_(mu)


def eval_set(net, seeds, K_users=K):
    out = []
    for s in seeds:
        u = md.make_users(s, K=K_users)
        q, rho, pw, m = m2.evaluate_policy(net, u)
        out.append(dict(seed=s, EE=m['EE'], sum_rate=m['sum_rate'], min_rate=m['min_rate'], jain=m['jain'],
                        rmin_ok=m['rmin_ok'], battery_ok=m['battery_ok'], E_tot=m['E_tot'], outage=m['outage']))
    return out


if __name__ == '__main__':
    nft = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    experts = pickle.load(open('out/expert.pkl', 'rb'))
    print('experts', len(experts), 'mean EE', np.mean([e['EE'] for e in experts]))
    O, A, G, _ = expert_data(experts)
    net = AC()
    bc(net, O, A, G)
    before = eval_set(net, range(10))
    print('BC only  EE %.0f  rminok %d/10  batt %d/10' % (np.mean([b['EE'] for b in before]), sum(b['rmin_ok'] for b in before), sum(b['battery_ok'] for b in before)), flush=True)
    torch.save(net.state_dict(), 'out/m2_bc.pt')
    net, curve = m2.train(nft, n_env=16, seed=1, log=sys.stdout, net=net, std0=-1.6, std1=-1.8, lr=1e-4)
    after = eval_set(net, range(10))
    print('BC+PPO   EE %.0f  rminok %d/10  batt %d/10' % (np.mean([b['EE'] for b in after]), sum(b['rmin_ok'] for b in after), sum(b['battery_ok'] for b in after)), flush=True)
    torch.save(net.state_dict(), 'out/m2_final.pt')
    json.dump(dict(curve=curve, before=before, after=after), open('out/m2_summary.json', 'w'))
