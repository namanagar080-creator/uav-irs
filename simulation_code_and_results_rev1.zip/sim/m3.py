"""M3 - multi-UAV cooperative scheduling.
U UAV-mounted IRSs, each fed by its own co-channel ground BS (BS_i, UAV altitude H+10*i).
Interference: IRS j (phase-aligned to its own user) leaks incoherently (M instead of M^2 gain) onto
every other active user.  Joint user association + interference coordination are solved by a
time-sharing LP over per-slot joint 'modes' (which user each UAV serves, or idle); trajectories are
refined per UAV by the same SCA/Dinkelbach step as M1.  Association is therefore soft (a user can be
served by several UAVs); the dominant server is reported.
"""
import numpy as np, itertools
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack
import model as md
from model import P, BS_POS, DEPOT
import m1


def kmeans_balanced(users, U, seed=0, iters=30):
    K = len(users); cap = int(np.ceil(K / U))
    rng = np.random.default_rng(seed)
    best, bl = None, 1e18
    for rs in range(20):
        c = users[rng.choice(K, U, replace=False)]
        for _ in range(iters):
            d = np.linalg.norm(users[:, None] - c[None], axis=2)
            lab = -np.ones(K, int); cnt = np.zeros(U, int)
            for k in np.argsort(d.min(1)):
                for j in np.argsort(d[k]):
                    if cnt[j] < cap:
                        lab[k] = j; cnt[j] += 1; break
            c = np.array([users[lab == j].mean(0) if (lab == j).any() else c[j] for j in range(U)])
        loss = sum(np.linalg.norm(users[lab == j] - c[j], axis=1).sum() for j in range(U))
        if loss < bl: bl, best = loss, lab.copy()
    return best


class Fleet:
    def __init__(self, users, U):
        self.users, self.U, self.K = users, U, len(users)
        self.bs = [BS_POS[i] for i in range(U)]
        self.H = [P['H'] + 10.0 * i for i in range(U)]
        self.C = self.K if U == 1 else min(3, self.K)

    def gains(self, Q):
        G = np.stack([md.gain(Q[i], self.bs[i], self.users, self.H[i], True) for i in range(self.U)])        # (U,N,K)
        return G

    # ---- joint scheduling LP over modes ----
    def schedule(self, Q, coordinated=True, rmin=None, fw=0.0):
        U, K, N = self.U, self.K, P['N']
        G = self.gains(Q)
        Iinc = G * (md.ZETA_RAND / md.ZETA)
        Pt = P['Pmax']; s2 = P['sigma2']; dl = P['delta']; B = P['B']
        C = self.C
        cand = np.argsort(-G, axis=2)[:, :, :C]                         # (U,N,C)
        opts = np.array(list(itertools.product(range(C + 1), repeat=U)))  # (nc,U); value C == idle
        nc = len(opts)
        # user served by each UAV in each (n,combo): (N,nc,U), -1 idle
        cand_ext = np.concatenate([cand, -np.ones((U, N, 1), int)], 2)    # (U,N,C+1)
        ku = np.stack([cand_ext[i][:, opts[:, i]] for i in range(U)], 2)  # (N,nc,U)
        active = ku >= 0
        # duplicate user in one combo -> invalid
        valid = np.ones((N, nc), bool)
        for i in range(U):
            for j in range(i + 1, U):
                valid &= ~((ku[:, :, i] == ku[:, :, j]) & active[:, :, i])
        nidx = np.arange(N)[:, None, None]
        kk = np.where(active, ku, 0)
        sig = np.zeros((N, nc, U)); intf = np.zeros((N, nc, U))
        for i in range(U):
            sig[:, :, i] = Pt * G[i][nidx[:, :, 0], kk[:, :, i]]
            for j in range(U):
                if j == i: continue
                intf[:, :, i] += np.where(active[:, :, j], Pt * Iinc[j][nidx[:, :, 0], kk[:, :, i]], 0.0)
        sinr = sig / (s2 + intf)
        bits = np.where(active, dl * B * np.log2(1 + sinr), 0.0)           # (N,nc,U)
        tx_act = active.sum(2)
        if not coordinated:
            return None
        # LP
        n_ids, c_ids = np.nonzero(valid)
        nv = len(n_ids)
        # slot rows
        A1 = coo_matrix((np.ones(nv), (n_ids, np.arange(nv))), shape=(N, nv + K))
        # user rows
        rows, cols, vals = [], [], []
        for i in range(U):
            m = active[n_ids, c_ids, i]
            rows.append(ku[n_ids, c_ids, i][m]); cols.append(np.nonzero(m)[0]); vals.append(-bits[n_ids, c_ids, i][m])
        rows = np.concatenate(rows); cols = np.concatenate(cols); vals = np.concatenate(vals)
        rows = np.concatenate([rows, np.arange(K)]); cols = np.concatenate([cols, nv + np.arange(K)]); vals = np.concatenate([vals, -np.ones(K)])
        A2 = coo_matrix((vals, (rows, cols)), shape=(K, nv + K))
        A = vstack([A1, A2]).tocsr()
        rm = P['Rmin'] if rmin is None else rmin
        b = np.concatenate([np.ones(N), -rm * np.ones(K)])
        tot = bits[n_ids, c_ids, :].sum(1)
        # energy-aware: a tiny cost for BS transmit time keeps idle modes when they bring nothing
        etx = dl * tx_act[n_ids, c_ids] * Pt / P['xi_pa']
        lam = getattr(self, 'lam', 0.0)
        cost = -(tot - lam * etx)
        if fw <= 0:
            c = np.concatenate([cost, np.full(K, 1e3 * max(1.0, np.abs(cost).max()))])
            res = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)] * (nv + K), method='highs')
        else:
            # fairness-aware variant: maximise  total bits + fw*K*min_k bits  (in Mbit for conditioning)
            sc = 1e-6
            A1f = coo_matrix((np.ones(nv), (n_ids, np.arange(nv))), shape=(N, nv + K + 1))
            ur, uc, uv = rows[:-K], cols[:-K], vals[:-K] * sc
            A2f = coo_matrix((np.concatenate([uv, -np.ones(K)]), (np.concatenate([ur, np.arange(K)]), np.concatenate([uc, nv + np.arange(K)]))), shape=(K, nv + K + 1))
            A3f = coo_matrix((np.concatenate([uv, np.ones(K)]), (np.concatenate([ur, np.arange(K)]), np.concatenate([uc, np.full(K, nv + K)]))), shape=(K, nv + K + 1))
            A = vstack([A1f, A2f, A3f]).tocsr()
            b = np.concatenate([np.ones(N), -rm * sc * np.ones(K), np.zeros(K)])
            costs = cost * sc
            c = np.concatenate([costs, np.full(K, 1e3 * max(1.0, np.abs(costs).max())), [-fw * K]])
            res = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)] * (nv + K + 1), method='highs')
        w = np.zeros((N, nc)); w[n_ids, c_ids] = res.x[:nv]
        return dict(w=w, ku=ku, active=active, bits=bits, sinr=sinr, tx_act=tx_act, G=G, opts=opts, valid=valid)

    def summarise(self, Q, S, rng=None, w=None):
        """metrics from schedule S (weights w overrides S['w'] e.g. for uncoordinated baseline)."""
        rng = np.random.default_rng(0) if rng is None else rng
        U, K, N = self.U, self.K, P['N']
        w = S['w'] if w is None else w
        ku, act, bits = S['ku'], S['active'], S['bits']
        bk = np.zeros(K); rho = np.zeros((U, N, K)); snr_list, w_list = [], []
        for i in range(U):
            for k in range(K):
                sel = act[:, :, i] & (ku[:, :, i] == k)
                bk[k] += (w * bits[:, :, i] * sel).sum()
                rho[i, :, k] = (w * sel).sum(1)
        Ep = sum(md.prop_energy(Q[i]) for i in range(U))
        Ec = float(sum(np.sum(P['delta'] * (w * S['tx_act']).sum(1) * P['Pmax'] / P['xi_pa'])
                       for _ in [0])) + U * P['M'] * P['Pel'] * P['T']
        Et = Ep + Ec
        # outage (weighted over active links) and coverage
        mask = act & (w[:, :, None] > 1e-6)
        snr = S['sinr'][mask]; ww = np.broadcast_to(w[:, :, None], act.shape)[mask]
        out = md.outage_mc(snr, ww, rng) if len(snr) else 1.0
        Gbest = S['G'].max(0)       # (N,K) best interference-free link
        cov = float(np.mean(P['Pmax'] * Gbest / P['sigma2'] >= P['gam_th']))
        dist = [np.linalg.norm(np.diff(np.vstack([DEPOT, Q[i]]), axis=0), axis=1).sum() for i in range(U)]
        tot = bk.sum()
        share = rho.sum(1)       # (U,K)
        dom = share.argmax(0)
        multi = float(np.mean((share > 0.05 * np.maximum(share.sum(0), 1e-9)).sum(0) > 1))
        return dict(EE=tot / Et, sum_rate=tot / P['T'], min_rate=bk.min() / P['T'], bits_k=bk,
                    E_prop=Ep, E_comm=Ec, E_tot=Et, endurance_h=P['Ebatt'] / (Et / U / P['T']) / 3600,
                    traj_len=float(sum(dist)), coverage=cov, outage=out, jain=md.jain(bk),
                    rmin_ok=bool(bk.min() >= P['Rmin'] * 0.995), dominant=dom, multi_served=multi, rho=rho)


def run_m3(users, U, max_iter=25, tol=1e-3, verbose=False, rng=None, Q_init=None):
    fl = Fleet(users, U)
    lab = kmeans_balanced(users, U)
    Q = []
    for i in range(U):
        us = users[lab == i] if (lab == i).any() else users[:1]
        Q.append(md.init_tour(us))
    Q = np.stack(Q) if Q_init is None else Q_init.copy()
    trust = 40.0; hist = []
    fl.lam = 0.0

    def ev(QQ):
        S = fl.schedule(QQ)
        m = fl.summarise(QQ, S, rng)
        short = max(0.0, 1 - m['bits_k'].min() / P['Rmin'])
        m['score'] = m['EE'] * (1 - 1e3 * short)
        return S, m
    S, m = ev(Q); hist.append(m['EE'])
    stall = 0
    for it in range(max_iter):
        lam = m['EE']; fl.lam = 0.0
        Qn = np.zeros_like(Q); ok = True
        rho = m['rho']; bits_u = np.zeros((U, fl.K))
        for i in range(U):
            # bits delivered to each user by the *other* UAVs
            other = np.zeros(fl.K)
            for j in range(U):
                if j == i: continue
                for k in range(fl.K):
                    sel = S['active'][:, :, j] & (S['ku'][:, :, j] == k)
                    other[k] += (S['w'] * S['bits'][:, :, j] * sel).sum()
            v = md.step_speeds(Q[i]); y0 = np.clip(m1.y_of_v(v), 1e-3, 1.0)
            qn, yn = m1.sca_step(Q[i], users, rho[i], P['Pmax'], lam, fl.bs[i], fl.H[i], P['Rmin'], other, y0, trust)
            if qn is None: ok = False; break
            Qn[i] = qn
        if not ok:
            trust *= 0.5
            if trust < 1: break
            continue
        acc = False
        for s in (1.0, 0.5, 0.25):
            Qc = Q + s * (Qn - Q)
            Sc, mc = ev(Qc)
            if mc['score'] > m['score'] * (1 + 1e-9): acc = True; break
        if not acc:
            trust *= 0.5; stall += 1
            if trust < 1 or stall >= 3: break
            continue
        g = (mc['score'] - m['score']) / abs(m['score'])
        Q, S, m = Qc, Sc, mc; hist.append(m['EE'])
        if verbose: print(it, 'EE=%.0f min=%.2e' % (m['EE'], m['bits_k'].min()))
        if g < tol:
            stall += 1
            if stall >= 2: break
        else: stall = 0
    m['hist'] = hist; m['iters'] = len(hist) - 1
    return Q, S, m, fl


def uncoordinated(users, U, Q, rng=None):
    """Ablation: every UAV runs its own M1-style scheduling (LP, no knowledge of others) and all transmit
    simultaneously; the expected interference is evaluated exactly by independent-schedule probabilities."""
    fl = Fleet(users, U)
    S = fl.schedule(Q)           # for tables (ku, bits...) -- interference-aware tables are needed
    G = S['G']; N = P['N']
    # independent per-UAV LP shares (each UAV aims at all users with its own Rmin share)
    lab = kmeans_balanced(users, U)       # static association, independent per-UAV LP scheduling
    rhos = []
    for i in range(U):
        idx = np.nonzero(lab == i)[0]
        r = np.zeros((N, fl.K))
        r[:, idx] = m1.schedule_lp(G[i][:, idx], P['Pmax'])
        rhos.append(r)
    # w = product of independent selection probabilities (idle prob = 1-sum)
    C = fl.C; opts = S['opts']; ku = S['ku']; nc = len(opts)
    w = np.ones((N, nc))
    for i in range(U):
        idle = np.clip(1 - rhos[i].sum(1), 0, 1)
        p = np.where(ku[:, :, i] >= 0, rhos[i][np.arange(N)[:, None], np.where(ku[:, :, i] >= 0, ku[:, :, i], 0)], idle[:, None])
        w *= p
    w = w * S['valid']
    return fl.summarise(Q, S, rng, w=w)


if __name__ == '__main__':
    import time, sys
    U = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    u = md.make_users(0, K=8)
    t = time.time()
    Q, S, m, fl = run_m3(u, U, verbose=True)
    print('time', time.time() - t)
    print({k: v for k, v in m.items() if k not in ('hist', 'rho', 'bits_k')}, m['bits_k'])
    mu = uncoordinated(u, U, Q)
    print('uncoord', {k: v for k, v in mu.items() if k in ('EE', 'min_rate', 'sum_rate', 'jain', 'outage')})
