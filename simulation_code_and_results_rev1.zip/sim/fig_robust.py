import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.alpha': 0.25})
R = json.load(open('out/robust.json')); DL = json.load(open('out/directlink.json'))
BLUE, ORG, GREY, PUR = '#2F5597', '#C55A11', '#7F7F7F', '#7030A0'
lagkeys = [k for k in R['sigma']['0'] if k.startswith('M2L')]


def series(kind, key, met):
    xs = sorted(R[kind], key=float)
    if key == 'M2L':
        return [float(x) for x in xs], [np.mean([R[kind][x][k][met] for k in lagkeys]) for x in xs]
    return [float(x) for x in xs], [R[kind][x][key][met] for x in xs]


fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.5), dpi=300)
for name, key, c, ls, mk in (('M1', 'M1', BLUE, '-', 'o'), ('Tour', 'tour', GREY, ':', 's'), ('M2 penalty-PPO', 'M2_old', ORG, '--', '^'), ('M2 constrained PPO (5 seeds)', 'M2L', PUR, '-.', 'v')):
    x, y = series('sigma', key, 'EE'); axs[0].plot(x, np.array(y) / 1e3, color=c, ls=ls, marker=mk, ms=3.5, lw=1.2, label=name)
    x, y = series('sigma', key, 'feas'); axs[1].plot(x, 100 * np.array(y), color=c, ls=ls, marker=mk, ms=3.5, lw=1.2)
axs[0].set_xlabel('Gain-estimation error σ (dB)'); axs[0].set_ylabel('Energy efficiency (kbit/J)')
axs[1].set_xlabel('Gain-estimation error σ (dB)'); axs[1].set_ylabel('Runs meeting rate floor (%)')
axs[0].set_ylim(14, 36); axs[0].set_yticks([15, 20, 25, 30]); axs[0].legend(fontsize=5.6, loc='upper right', ncol=2)
lbs = list(DL.keys()); lab = ['blocked' if l == 'None' else l for l in lbs]
x = np.arange(len(lbs))
axs[2].plot(x, [DL[l]['M1+IRS']['EE'] / 1e3 for l in lbs], color=BLUE, marker='o', ms=3.5, lw=1.2, label='M1 + IRS')
axs[2].plot(x, [DL[l]['M1 traj, random phases']['EE'] / 1e3 for l in lbs], color=GREY, ls='--', marker='s', ms=3.5, lw=1.2, label='Same path, random phases')
axs[2].set_xticks(x); axs[2].set_xticklabels(lab); axs[2].set_xlabel('Extra direct-link blockage loss (dB)'); axs[2].set_ylabel('Energy efficiency (kbit/J)')
axs[2].legend(fontsize=5.6, loc='upper left')
fig.tight_layout(); fig.savefig('figs/fig7_robust.png', dpi=300)
