"""Fix #6: EE-fairness trade-off of M3 scheduling (fairness weight fw) on the stored scaling trajectories."""
import json, pickle, numpy as np, warnings
warnings.filterwarnings('ignore')
import model as md, m3
scl = pickle.load(open('out/scaling.pkl', 'rb'))
FW = [0.0, 0.25, 1.0, 4.0, 100.0]
out = {}
for U in (1, 2, 3, 4):
    out[U] = {}
    for fw in FW:
        v = []
        for r in scl:
            if r['U'] != U: continue
            fl = m3.Fleet(r['users'], U)
            S = fl.schedule(r['Q'], fw=fw)
            m = fl.summarise(r['Q'], S, np.random.default_rng(r['seed']))
            v.append((m['EE'], m['jain'], m['sum_rate'], m['min_rate'], m['rmin_ok']))
        a = np.array(v, float)
        out[U][fw] = dict(EE=(a[:, 0].mean(), a[:, 0].std(ddof=1)), jain=(a[:, 1].mean(), a[:, 1].std(ddof=1)), sum_rate=(a[:, 2].mean(), a[:, 2].std(ddof=1)), min_rate=(a[:, 3].mean(), a[:, 3].std(ddof=1)), feas=int(a[:, 4].sum()))
        print(U, fw, 'EE %.0f jain %.3f sum %.2f min %.3f feas %d' % (a[:, 0].mean(), a[:, 1].mean(), a[:, 2].mean() / 1e6, a[:, 3].mean() / 1e6, a[:, 4].sum()), flush=True)
json.dump({str(k): {str(f): v for f, v in d.items()} for k, d in out.items()}, open('out/fairness.json', 'w'), indent=1)
