"""Helpers that emit paragraphs/tables/equations matching the journal template's exact formatting."""
import re, copy, subprocess, zipfile, os, tempfile
from xml.sax.saxutils import escape
from docx import Document
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

W = nsdecls('w')


def _rpr(sz=22, b=False, i=False, color=None, sup=False, sub=False, hl=None):
    s = '<w:rPr>'
    if b: s += '<w:b/><w:bCs/>'
    if i: s += '<w:i/><w:iCs/>'
    if color: s += '<w:color w:val="%s"/>' % color
    s += '<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (sz, sz)
    if hl: s += '<w:highlight w:val="%s"/>' % hl
    if sup: s += '<w:vertAlign w:val="superscript"/>'
    if sub: s += '<w:vertAlign w:val="subscript"/>'
    return s + '</w:rPr>'


TOK = re.compile(r'(\*\*.+?\*\*|\*.+?\*|\^.+?\^|~.+?~|==.+?==)')


def runs(text, sz=22, b=False, i=False, color=None):
    """tiny markup: **bold**  *italic*  ^sup^  ~sub~  ==highlight=="""
    out = ''
    for part in TOK.split(text):
        if not part: continue
        kw = dict(sz=sz, b=b, i=i, color=color)
        if part.startswith('**'): part = part[2:-2]; kw['b'] = True
        elif part.startswith('==') and part.endswith('=='): part = part[2:-2]; kw['hl'] = 'yellow'
        elif part.startswith('*') and part.endswith('*') and len(part) > 2: part = part[1:-1]; kw['i'] = True
        elif part.startswith('^'): part = part[1:-1]; kw['sup'] = True; kw['sz'] = min(sz, 16)
        elif part.startswith('~'): part = part[1:-1]; kw['sub'] = True; kw['sz'] = min(sz, 16)
        out += '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (_rpr(**kw), escape(part))
    return out


class Builder:
    def __init__(self, template):
        self.doc = Document(template)
        body = self.doc.element.body
        self.sect = body.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}sectPr')
        for el in list(body):
            if el is not self.sect:
                body.remove(el)
        self.body = body
        self.cites = {}      # source id -> displayed number (first-citation order)
        self.order = []

    # ---- citations
    def cite(self, text):
        def rep(m):
            nums = []
            for sid in m.group(1).split(','):
                sid = int(sid)
                if sid not in self.cites:
                    self.cites[sid] = len(self.cites) + 1
                nums.append(self.cites[sid])
            nums.sort()
            return ', '.join('[%d]' % n for n in nums)
        return re.sub(r'⟦([\d,]+)⟧', rep, text)

    def _add(self, xml):
        el = parse_xml(xml)
        self.sect.addprevious(el)
        return el

    def p(self, xml_inner, ppr):
        return self._add('<w:p %s><w:pPr>%s</w:pPr>%s</w:p>' % (W, ppr, xml_inner))

    # ---- block types
    def title(self, t):
        self.p(runs(t, sz=30, b=True), '<w:spacing w:before="240" w:after="160"/><w:jc w:val="center"/>')

    def authors(self, parts):
        """parts: list of (name, sup) """
        inner = ''
        for k, (n, sup) in enumerate(parts):
            inner += runs((', ' if k else '') + n, sz=22) + runs('^%s^' % sup, sz=16)
        self.p(inner, '<w:spacing w:after="60"/><w:jc w:val="center"/>')

    def affil(self, sup, text):
        self.p(runs('^%s^' % sup, sz=16) + runs(' ' + text, sz=19, i=True), '<w:spacing w:after="40"/><w:jc w:val="center"/>')

    def centre_small(self, text, grey=False, last=False):
        self.p(runs(text, sz=19, i=True, color='6A6A6A' if grey else None),
               '<w:spacing w:after="%d"/><w:jc w:val="center"/>' % (240 if last else 40))

    def h_abstract(self, t='Abstract'):
        self.p(runs(t, sz=24, b=True, color='1F3864'), '<w:spacing w:before="120" w:after="100"/>')

    def h1(self, t):
        self.p(runs(t, sz=26, b=True, color='1F3864'), '<w:pStyle w:val="2"/><w:spacing w:before="320" w:after="120"/>')

    def h2(self, t):
        self.p(runs(t, sz=23, b=True, color='2F4F7F'), '<w:pStyle w:val="3"/><w:spacing w:before="220" w:after="100"/>')

    def para(self, t):
        t = self.cite(t)
        self.p(runs(t, sz=22), '<w:spacing w:after="120" w:line="276" w:lineRule="auto"/><w:jc w:val="both"/>')

    def keywords(self, t):
        self.p(runs('Keywords: ', sz=22, b=True) + runs(t, sz=22), '<w:spacing w:before="160" w:after="240"/>')

    def bullet(self, t):
        t = self.cite(t)
        self.p(runs(t, sz=22), '<w:pStyle w:val="16"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr><w:spacing w:after="60"/><w:jc w:val="both"/>')

    def declaration(self, label, t):
        self.p(runs(label + ' ', sz=22, b=True) + runs(t, sz=22), '<w:spacing w:after="80"/><w:jc w:val="both"/>')

    def ref(self, n, text):
        self.p(runs('[%d]' % n, sz=20) + '<w:r><w:tab/></w:r>' + runs(text, sz=20),
               '<w:tabs><w:tab w:val="left" w:pos="567"/></w:tabs><w:spacing w:after="60"/><w:ind w:left="567" w:hanging="567"/><w:jc w:val="both"/>')

    def caption(self, label, text):
        text = self.cite(text)
        self.p(runs(label, sz=19, b=True) + runs(' ' + text, sz=19), '<w:spacing w:before="80" w:after="160"/><w:jc w:val="center"/>')

    def caption_above(self, label, text):
        text = self.cite(text)
        self.p(runs(label, sz=19, b=True) + runs(' ' + text, sz=19), '<w:keepNext/><w:spacing w:before="120" w:after="80"/><w:jc w:val="center"/>')

    # ---- equation (real OMML, centre tab + right-aligned number)
    def equation(self, latex, num):
        omml = latex_to_omml(latex)
        omml = omml.replace('<m:oMath>', '<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">', 1)
        M = 'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"'
        nb = '<w:tcBorders>' + ''.join('<w:%s w:val="nil"/>' % t for t in ('top', 'left', 'bottom', 'right')) + '</w:tcBorders>'
        def tc(w, inner):
            return '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s<w:vAlign w:val="center"/></w:tcPr>%s</w:tc>' % (w, nb, inner)
        mid = '<w:p><w:pPr><w:spacing w:before="60" w:after="60"/><w:jc w:val="center"/></w:pPr>%s</w:p>' % omml
        right = '<w:p><w:pPr><w:spacing w:before="60" w:after="60"/><w:jc w:val="right"/></w:pPr>%s</w:p>' % runs('(%d)' % num, sz=22)
        left = '<w:p><w:pPr><w:spacing w:after="0"/></w:pPr></w:p>'
        xml = ('<w:tbl %s %s><w:tblPr><w:tblW w:w="9026" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="900"/><w:gridCol w:w="7226"/><w:gridCol w:w="900"/></w:tblGrid><w:tr>%s%s%s</w:tr></w:tbl>') % (W, M, tc(900, left), tc(7226, mid), tc(900, right))
        self._add(xml)

    # ---- picture in a bordered cell (replaces the dashed placeholder box)
    def figure(self, path, width_cm, label, cap):
        from docx.shared import Cm
        tmp = self.doc.add_paragraph()           # appended before sectPr by python-docx
        tmp.alignment = 1
        tmp.paragraph_format.space_before = 0
        tmp.paragraph_format.keep_with_next = True
        tmp.add_run().add_picture(path, width=Cm(width_cm))
        self.caption(label, cap)

    # ---- table styled like the template (navy header, white bold 9.5pt)
    def table(self, header, rows, widths, align=None, bold_rows=(), size=19, note_rows=()):
        n = len(header); tot = sum(widths)
        widths = [int(w * 9026 / tot) for w in widths]
        align = align or ['left'] * n

        def cell(txt, w, hdr=False, bold=False, jc='left', shade=None):
            txt = self.cite(txt)
            fill = '1F3864' if hdr else shade
            shd = '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % fill if fill else ''
            r = runs(txt, sz=size, b=hdr or bold, color='FFFFFF' if hdr else None)
            return ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s<w:vAlign w:val="center"/><w:tcMar><w:top w:w="50" w:type="dxa"/><w:left w:w="90" w:type="dxa"/>'
                    '<w:bottom w:w="50" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:spacing w:after="0"/><w:jc w:val="%s"/></w:pPr>%s</w:p></w:tc>') % (w, shd, jc, r)
        bd = ''.join('<w:%s w:val="single" w:color="auto" w:sz="4" w:space="0"/>' % s for s in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'))
        x = '<w:tbl %s><w:tblPr><w:tblStyle w:val="9"/><w:tblW w:w="9026" w:type="dxa"/><w:tblInd w:w="0" w:type="dxa"/><w:tblBorders>%s</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="10" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="10" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>%s</w:tblGrid>' % (
            W, bd, ''.join('<w:gridCol w:w="%d"/>' % w for w in widths))
        x += '<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>%s</w:tr>' % ''.join(cell(h, widths[k], hdr=True, jc=('left' if align[k] == 'left' else 'center')) for k, h in enumerate(header))
        for ri, row in enumerate(rows):
            shade = 'F2F2F2' if ri % 2 == 1 else None
            x += '<w:tr><w:trPr><w:cantSplit/></w:trPr>%s</w:tr>' % ''.join(
                cell(c, widths[k], bold=(ri in bold_rows), jc=align[k], shade=shade) for k, c in enumerate(row))
        x += '</w:tbl>'
        self._add(x)
        self.p('', '<w:spacing w:after="40"/>')

    def pagebreak(self):
        self._add('<w:p %s><w:r><w:br w:type="page"/></w:r></w:p>' % W)

    def set_header(self, text):
        sec = self.doc.sections[0]
        for p in sec.header.paragraphs:
            for r in p.runs:
                if r.text.strip():
                    r.text = text
                    break

    def save(self, path):
        self.doc.save(path)


_cache = {}


def latex_to_omml(tex):
    if tex in _cache: return _cache[tex]
    d = tempfile.mkdtemp()
    f = os.path.join(d, 'e.docx')
    subprocess.run(['pandoc', '-f', 'markdown', '-t', 'docx', '-o', f], input=('$$' + tex + '$$\n').encode(), check=True)
    x = zipfile.ZipFile(f).read('word/document.xml').decode()
    m = re.search(r'<m:oMath>.*?</m:oMath>', x, re.S)
    _cache[tex] = m.group(0)
    return _cache[tex]
