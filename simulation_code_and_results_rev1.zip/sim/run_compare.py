"""Joint evaluation (P5/P6): identical scenarios (seeds 0-9, K=6 users) for baselines, M1, M2, M3(U=2)."""
import sys, pickle, time, warnings, numpy as np, torch
torch.set_num_threads(1)
warnings.filterwarnings('ignore')
import model as md, m1, m2, m3
from model import P, DEPOT, BS_POS

seeds = range(10)
net = m2.AC(); net.load_state_dict(torch.load('out/m2_final2.pt')); net.eval()
net_bc = m2.AC(); net_bc.load_state_dict(torch.load('out/m2_bc.pt')); net_bc.eval()
drop = ('rho', 'hist')
strip = lambda d: {k: v for k, v in d.items() if k not in drop}


def hover_baseline(u, rng):
    """Static hover at the best grid position (EE-optimal), LP scheduling, same constraints."""
    best = None
    gx = np.linspace(20, 380, 19)
    for x in gx:
        for y in gx:
            q = np.tile([x, y], (P['N'], 1)).astype(float)
            G = md.gain(q, BS_POS[0], u, P['H'])
            rho = m1.schedule_lp(G, P['Pmax'])
            m = md.metrics_single(q, u, rho, P['Pmax'], rng=rng, start=np.array([x, y]))
            # hover mission has no flight leg; add the 2 transit legs depot->hover->depot at 10 m/s
            d = np.linalg.norm(np.array([x, y]) - DEPOT)
            Etr = 2 * (d / 10.0) * float(md.prop_power(10.0))
            ok = m['bits_k'].min() >= P['Rmin'] * 0.995
            score = m['bits_k'].sum() / (m['E_tot'] + Etr) * (1 if ok else 1e-3)
            if best is None or score > best[0]:
                best = (score, q, rho, m, Etr)
    sc, q, rho, m, Etr = best
    m = dict(m); m['E_prop'] += Etr; m['E_tot'] += Etr; m['EE'] = m['bits_k'].sum() / m['E_tot']
    m['endurance_h'] = P['Ebatt'] / (m['E_tot'] / P['T']) / 3600
    return q, rho, m


out = []
for s in seeds:
    t0 = time.time()
    u = md.make_users(s, K=6)
    rng = np.random.default_rng(s)
    r = dict(seed=s, users=u)
    # B0 hover
    q, rho, m = hover_baseline(u, rng); r['hover'] = strip(m); r['q_hover'] = q
    # B1 naive tour + LP scheduling (no trajectory optimisation)
    q0 = md.init_tour(u); G = md.gain(q0, BS_POS[0], u, P['H']); rho0 = m1.schedule_lp(G, P['Pmax'])
    r['tour'] = strip(md.metrics_single(q0, u, rho0, P['Pmax'], rng=rng)); r['q_tour'] = q0
    # M1
    q1, rho1, m1r = m1.run_m1(u, rng=rng)
    r['M1'] = strip(m1r); r['M1']['hist'] = m1r['hist']; r['q_M1'] = q1; r['rho_M1'] = rho1
    # ablation: M1 trajectory but random IRS phases (no phase control) and phase resolution sweep
    for name, gs in [('M1_randphase', md.ZETA_RAND / md.ZETA)]:
        rr = m1.schedule_lp(md.gain(q1, BS_POS[0], u, P['H']) * gs, P['Pmax'])
        r[name] = strip(md.metrics_single(q1, u, rr, P['Pmax'], rng=rng, gscale=gs))
    for b in (1, 2, 3, 4, None):
        z = md.phase_quant_factor(b) if b else 1.0
        gs = z / md.ZETA
        rr = m1.schedule_lp(md.gain(q1, BS_POS[0], u, P['H']) * gs, P['Pmax'])
        r['M1_bits_%s' % b] = strip(md.metrics_single(q1, u, rr, P['Pmax'], rng=rng, gscale=gs))
    # M2 (BC+PPO) and BC-only
    for name, nn_ in (('M2', net), ('M2_bc', net_bc)):
        qd, rhod, pw, md_ = m2.evaluate_policy(nn_, u)
        r[name] = strip(md_); r['q_' + name] = qd; r['rho_' + name] = rhod; r['pw_' + name] = pw
    # M3, U = 2
    Q, S, m3r, fl = m3.run_m3(u, 2, rng=rng)
    r['M3'] = strip(m3r); r['M3']['hist'] = m3r['hist']; r['Q_M3'] = Q
    r['M3']['dominant'] = m3r['dominant']
    mu = m3.uncoordinated(u, 2, Q, rng=rng); r['M3_uncoord'] = strip(mu)
    out.append(r)
    pickle.dump(out, open('out/compare.pkl', 'wb'))
    print('seed %d  hover %.0f tour %.0f M1 %.0f M2 %.0f (rmin %s) M3 %.0f   %.0fs' % (
        s, r['hover']['EE'], r['tour']['EE'], r['M1']['EE'], r['M2']['EE'], r['M2']['rmin_ok'], r['M3']['EE'], time.time() - t0), flush=True)
