"""Continue PPO fine-tuning of the BC+PPO policy for more updates (same settings)."""
import sys, json, torch, numpy as np, warnings
warnings.filterwarnings("ignore"); torch.set_num_threads(1)
import m2, m2b
nft = int(sys.argv[1]) if len(sys.argv) > 1 else 2500
net = m2.AC(); net.load_state_dict(torch.load('out/m2_final.pt'))
prev = json.load(open('out/m2_summary.json'))
net, curve = m2.train(nft, n_env=16, seed=2, log=sys.stdout, net=net, std0=-1.8, std1=-2.0, lr=1e-4)
after = m2b.eval_set(net, range(10))
print('BC+PPO(cont) EE %.0f rminok %d/10 batt %d/10' % (np.mean([b['EE'] for b in after]), sum(b['rmin_ok'] for b in after), sum(b['battery_ok'] for b in after)), flush=True)
torch.save(net.state_dict(), 'out/m2_final2.pt')
json.dump(dict(curve=prev['curve'] + curve, before=prev['before'], after=after, after_500=prev['after']), open('out/m2_summary2.json', 'w'))
