import json, numpy as np, pickle
from scipy import stats
import model as md
from model import P
from docx_lib import Builder
import refs as R

TPL = '/root/.claude/uploads/4601cdbc-6b06-5104-a4a4-e73f870f1cb8/a4eba8f9-Journal_Manuscript_Template_with_Formatting_Instructions_1.docx'
S = json.load(open('out/summary.json'))
M2S = json.load(open('out/m2_summary2.json'))
REF = R.load()
sc = S['scaling']
f = lambda k, m, d=2, s=1.0: '%.*f ± %.*f' % (d, S[k][m][0] / s, d, S[k][m][1] / s)
mean = lambda k, m, d=2, s=1.0: '%.*f' % (d, S[k][m][0] / s)
def pv(p): return '< 0.001' if p < 1e-3 else '%.2f' % p if p >= 0.01 else '%.3f' % p
n_test = 10
Ecomm_share = 100 * S['M1']['E_comm'][0] / S['M1']['E_tot'][0]
mu_speed = S['M1']['traj_len'][0] / P['T']
ph = S['phase']
loss2 = 100 * (1 - ph['M1_bits_2'][0] / ph['M1_bits_None'][0])
bc_batt = sum(1 for b in M2S['before'] if b['battery_ok'])
m2_min_frac = 100 * S['M2']['min_rate'][0] / (P['Rmin'] / P['T'])
sum_ratio = S['M3']['sum_rate'][0] / S['M1']['sum_rate'][0]

B = Builder(TPL)
B.set_header('Energy-efficient UAV-mounted IRS communication · Manuscript draft')

# ------------------------------------------------------------ title block
B.title('Energy-Efficient UAV-Mounted IRS Communication: Alternating Optimisation, Deep Reinforcement Learning and Multi-UAV Scheduling Compared')
B.authors([('==[First Author]==', '1'), ('==[Second Author]==', '2'), ('==[Third Author]==', '1,*')])
B.affil('1', '==[Department, Institution, City, Postcode, Country]==')
B.affil('2', '==[Department, Institution, City, Postcode, Country]==')
B.centre_small('* Corresponding author: ==[email@institution.edu]==')
B.centre_small('ORCID: ==[0000-0000-0000-0000]==', grey=True, last=True)

# ------------------------------------------------------------ abstract
B.h_abstract()
abstract = (
    'Unmanned aerial vehicles (UAVs) carrying intelligent reflecting surfaces (IRSs) can extend coverage, but rotary-wing propulsion dominates the energy budget, so flight path and IRS configuration must be designed together. '
    'Existing work optimises trajectory and passive beamforming for single UAVs, while learning-based and multi-UAV designs are rarely benchmarked against an optimisation baseline under the same energy model. '
    'This paper compares three approaches to maximising energy efficiency (bits per joule) under per-user rate floors and a return-to-depot constraint: a joint alternating optimisation of trajectory, IRS phases and time-division scheduling (M1), a proximal policy optimisation agent with a battery constraint (M2), and cooperative scheduling of several UAV-IRS nodes (M3). '
    'All methods were evaluated in a synthetic 3.5 GHz scenario with a rotary-wing power model, on ten identical six-user layouts (five eight-user layouts for fleet scaling). '
    'M1 reached %s kbit/J, %.1f%% above a nearest-neighbour tour (paired p %s) while meeting every user\'s rate floor; random IRS phases cut efficiency by %.0f%% and 2-bit phase shifters cost %.1f%% against continuous phases. '
    'The reinforcement-learning agent respected the battery budget in all runs but reached only %s kbit/J and met the rate floor in none, giving the weakest result. '
    'Two cooperating UAVs delivered %.2f times the sum rate of M1 at statistically indistinguishable efficiency (%s kbit/J, p = %.2f), and interference-aware joint scheduling met the rate floor in all scaling runs where uncoordinated operation failed in most. '
    'The results indicate that, for this problem class, structured optimisation remains the stronger baseline, and that fleet size should be matched to demand because efficiency falls once capacity exceeds it.'
) % (f('M1', 'EE', 1, 1e3), S['M1_vs_tour_pct'], pv(S['tour']['p_vs_M1']),
     100 * (1 - S['M1_randphase']['EE'][0] / S['M1']['EE'][0]), loss2,
     f('M2', 'EE', 1, 1e3), sum_ratio, f('M3', 'EE', 1, 1e3), S['M3']['p_vs_M1'])
B.p(__import__('docx_lib').runs(abstract, sz=22), '<w:spacing w:after="120" w:line="276" w:lineRule="auto"/><w:jc w:val="both"/>')
B.keywords('UAV communication; intelligent reflecting surface; trajectory optimisation; proximal policy optimisation; multi-UAV scheduling')

# ------------------------------------------------------------ 1 Introduction
B.h1('1. Introduction')
B.para('Unmanned aerial vehicles (UAVs) are attractive wireless platforms because they can be positioned where demand is, but their usefulness is bounded by on-board energy ⟦4,5⟧. For a rotary-wing UAV the propulsion power is on the order of a hundred watts and varies non-monotonically with speed, whereas the radio transmission power is a small fraction of it ⟦2,3⟧. Intelligent reflecting surfaces (IRSs) offer a complementary lever: a passive array of tunable reflectors can steer a signal coherently towards a user without a radio-frequency chain ⟦6⟧. Mounting the IRS on the UAV, or serving users through it, couples the two problems, since the flight path determines both the energy spent and the quality of the cascaded channel ⟦11,12⟧.')
B.para('The dominant line of work formulates a joint trajectory and passive-beamforming problem and solves it by alternating optimisation and successive convex approximation ⟦7,8,10,13⟧. Closed-form outage and capacity analyses complement these designs ⟦9,16⟧, and several studies adopt energy efficiency as the objective, using fractional programming with trajectory updates ⟦15,17,18,19⟧ or finite-blocklength and sensing-integrated variants ⟦20,21⟧. In parallel, deep reinforcement learning (DRL) has been applied to aerial reflecting surfaces, wireless power transfer, charging-aware mobile edge computing and multi-UAV resource assignment ⟦22,27,29,30⟧.')
B.para('What is missing is a like-for-like comparison. Optimisation-based and learning-based designs are normally evaluated in different scenarios and under different energy models, and multi-UAV extensions are rarely quantified against a single-UAV optimum with a stated interference model. As a result it is unclear how much of the headline gain of a learned or multi-UAV scheme survives when the same propulsion model, the same rate constraints and the same random user layouts are imposed on every method.')
B.para('This paper therefore benchmarks three methodologies for maximising the energy efficiency (EE) of a UAV-mounted IRS network, on identical scenarios and with one shared evaluation routine.')
B.para('The principal contributions of this work are as follows:')
B.bullet('A joint alternating-optimisation scheme (M1) in which IRS phases are set in closed form, user time-shares are obtained from a linear programme, and the trajectory is refined by a Dinkelbach-based successive convex approximation that respects the rotary-wing power curve and a return-to-depot constraint.')
B.bullet('A battery-constrained proximal policy optimisation agent (M2) that controls velocity, transmit power and the IRS user-share as one sequential decision problem, together with a documented account of why it did not satisfy the per-user rate floors.')
B.bullet('A multi-UAV cooperative scheduler (M3) that solves user association and interference coordination jointly through a time-sharing linear programme over per-slot joint modes, with a fleet-scaling study of efficiency, rate, coverage and fairness.')
B.bullet('A controlled comparison over ten identical layouts with paired significance tests and ablations on IRS phase control and phase resolution, showing that M1 improves EE by %.1f%% over a tour baseline and that the learning-based agent does not match it.' % S['M1_vs_tour_pct'])
B.para('The remainder of this paper is organised as follows. Section 2 reviews related work. Section 3 describes the proposed methodology. Section 4 presents the experimental results. Section 5 discusses the findings and limitations, and Section 6 concludes.')

# ------------------------------------------------------------ 2 Literature review
B.h1('2. Literature Review')
B.h2('2.1 UAV communication and energy foundations')
B.para('The air-to-ground channel is commonly modelled through an elevation-dependent line-of-sight (LoS) probability, which exposes an optimal altitude for coverage ⟦1⟧. Energy-aware design starts from an explicit propulsion model: a fixed-wing model for energy-efficient trajectories ⟦2⟧ and a rotary-wing model with blade-profile, induced and parasitic terms for energy minimisation ⟦3⟧. Surveys and tutorials place these models in the wider context of applications, challenges and open problems ⟦4,5⟧. Together they establish two facts that the present work relies on: propulsion energy cannot be neglected, and the power curve of a rotary-wing UAV has an interior minimum, so neither hovering nor flying fast is energy-optimal.')
B.h2('2.2 IRS-assisted UAV communication: joint trajectory and beamforming')
B.para('Joint active and passive beamforming for IRS-aided networks was introduced for terrestrial systems ⟦6⟧ and soon extended to UAVs. Joint trajectory and passive-beamforming designs for IRS-assisted UAV links ⟦7,8,13⟧, OFDMA sum-rate maximisation ⟦10⟧ and UAV-borne reflecting surfaces for relaying ⟦11⟧ all rely on alternating optimisation, with the UAV either as a transmitter or as the carrier of the surface. Analytical studies derive closed-form outage and ergodic capacity for dual-hop ⟦9⟧ and multi-layer ⟦25⟧ IRS-UAV links, the latter showing that imperfect phase compensation matters for realistic performance. Framing articles ⟦12⟧ and multi-IRS multi-UAV designs for edge computing ⟦14⟧ indicate where the field is heading, but the objective in most of these works is throughput rather than energy.')
B.h2('2.3 Energy efficiency, learning-based and multi-UAV designs')
B.para('Energy efficiency has been tackled with early power-efficiency formulations ⟦15⟧, green-communication analyses ⟦16⟧, IRS-on-UAV designs that combine Dinkelbach iterations with successive convex approximation ⟦17⟧, joint scheduling with simultaneous wireless information and power transfer (SWIPT) ⟦18⟧, particle-swarm solutions ⟦19⟧, short-packet links ⟦20⟧ and sensing-integrated systems under statistical channel knowledge ⟦21⟧. Security-oriented ⟦23,26⟧ and robust learning-based ⟦24⟧ variants add constraints rather than change the energy model. Learning-based work uses DRL for age-of-information with an aerial IRS ⟦22⟧, power transfer ⟦27⟧, multi-objective trajectory design with wireless charging ⟦29⟧, three-dimensional trajectories with obstacles ⟦28⟧ and graph-attention assignment for several UAVs ⟦30⟧. These studies report results in their own scenarios; they do not share a scenario, an energy model or a baseline, which prevents direct comparison.')
B.h2('2.4 Research gap')
B.para('Table 1 summarises representative studies. To our reading none compares an optimisation baseline, a constrained DRL agent and a multi-UAV scheduler on one propulsion-aware IRS-UAV scenario with identical layouts and metrics. The present study fills that gap. The table entries are condensed from titles and abstract-level information and should be checked against the full texts before submission.')
B.caption_above('Table 1.', 'Comparison of related work and the gap addressed by this study.')
B.table(['Study', 'Approach', 'Dataset / setting', 'Limitation'],
        [['Li et al., 2020 ⟦7⟧', 'Joint trajectory and passive beamforming', 'IRS-assisted UAV link', 'Throughput-oriented; no propulsion-aware EE objective, no learning or fleet comparison'],
         ['Su et al., 2022 ⟦17⟧', 'Dinkelbach + SCA for EE', 'IRS mounted on UAV', 'Optimisation only; no DRL benchmark or fleet scaling'],
         ['Zargari et al., 2023 ⟦18⟧', 'EE with user scheduling and SWIPT', 'IRS-UAV network', 'No DRL comparison or multi-UAV interference study'],
         ['Samir et al., 2021 ⟦22⟧', 'DRL for age of information', 'Aerial IRS', 'Information-freshness objective; no optimisation baseline'],
         ['Song et al., 2024 ⟦29⟧', 'Multi-objective RL, wireless charging', 'UAV-assisted MEC', 'No IRS phase control'],
         ['Feng et al., 2024 ⟦30⟧', 'Graph-attention RL', 'Multi-UAV communication', 'No IRS; no propulsion/phase co-design'],
         ['This work', 'M1 alternating optimisation, M2 PPO, M3 multi-UAV scheduling', 'UAV-mounted IRS, 3.5 GHz synthetic scenario, 10 shared layouts', 'Simulation with a synthetic channel model only']],
        [2.1, 2.6, 2.4, 3.2], bold_rows=(6,))

# ------------------------------------------------------------ 3 Methodology
B.h1('3. Methodology')
B.h2('3.1 Problem formulation')
B.para('A ground base station (BS) at **b** with antenna height H~b~ feeds an IRS with M elements carried by a rotary-wing UAV flying at altitude H. The UAV serves K single-antenna ground users at positions **w**~k~ over a mission of duration T divided into N slots of length δ = T/N. The UAV position in slot n is **q**~n~, it starts and ends at a depot **q**~0~, and its speed is limited to V~max~. The direct BS-user link is assumed blocked, so every user is served through the IRS. With the IRS phases aligned to the scheduled user, and ζ the coherent-gain factor of b-bit phase shifters, the end-to-end power gain is')
B.equation(r'g_{n,k}=\frac{\zeta M^{2}\beta_{1}\beta_{2}\,\eta(r_{n,k})}{\left(\lVert \mathbf{q}_{n}-\mathbf{b}\rVert^{2}+(H-H_{b})^{2}\right)\left(\lVert \mathbf{q}_{n}-\mathbf{w}_{k}\rVert^{2}+H^{2}\right)}', 1)
B.para('where β~1~ and β~2~ are the free-space gains at 1 m of the BS-IRS and IRS-user links (the former including the BS antenna gain), r~n,k~ is the horizontal IRS-user distance, and η(r) = P~LoS~(r) + (1 − P~LoS~(r))η~NLoS~ is the expected excess-loss factor with the elevation-dependent LoS probability P~LoS~ of ⟦1⟧. Both hops use a path-loss exponent of two. A user scheduled for a fraction ρ~n,k~ of slot n (Σ~k~ ρ~n,k~ ≤ 1, time-division within the slot) with BS transmit power p~n~ obtains the rate')
B.equation(r'R_{n,k}=B\log_{2}\!\left(1+\frac{p_{n}\,g_{n,k}}{\sigma^{2}}\right)', 2)
B.para('where B is the bandwidth and σ^2^ the noise power. The rotary-wing propulsion power at speed V follows ⟦3⟧')
B.equation(r'P_{\mathrm{prop}}(V)=P_{0}\!\left(1+\frac{3V^{2}}{U_{\mathrm{tip}}^{2}}\right)+P_{i}\!\left(\sqrt{1+\frac{V^{4}}{4v_{0}^{4}}}-\frac{V^{2}}{2v_{0}^{2}}\right)^{1/2}+\tfrac{1}{2}d_{0}\rho_{a} sAV^{3}', 3)
B.para('with the parameters of Table 2. The total energy is the sum of propulsion energy, the BS transmit energy (including power-amplifier efficiency ξ) and the IRS control-circuit energy, with P~e~ the per-element circuit power:')
B.equation(r'E_{\mathrm{tot}}=\sum_{n=1}^{N}\delta\left[P_{\mathrm{prop}}\!\left(\frac{\lVert \mathbf{q}_{n}-\mathbf{q}_{n-1}\rVert}{\delta}\right)+\frac{p_{n}\sum_{k}\rho_{n,k}}{\xi}+MP_{e}\right]', 4)
B.para('The optimisation problem is to maximise energy efficiency over the trajectory, the time-shares, the transmit powers and the IRS phases:')
B.equation(r'\max_{\mathbf{q},\boldsymbol{\rho},\mathbf{p},\boldsymbol{\theta}}\ \ \mathrm{EE}=\frac{\sum_{n}\sum_{k}\delta\,\rho_{n,k}R_{n,k}}{E_{\mathrm{tot}}}', 5)
B.para('subject to a per-user delivered-bits floor Σ~n~ δρ~n,k~R~n,k~ ≥ R~min~ for every user, the speed limit ‖**q**~n~ − **q**~n−1~‖ ≤ V~max~δ, and **q**~N~ = **q**~0~. Problem (5) is non-convex because of the coupled distance terms in (1) and the non-monotone power curve (3). The IRS phases θ do not appear explicitly in (5): for a scheduled user they take the closed-form conjugate-alignment value θ~m~ = −arg(h~1,m~h~2,m~), quantised to b bits, which is captured by ζ. We verified this at element level on a 64-element uniform planar array with random angles, obtaining ζ = %.3f for b = 2 bits, against 1/M = %.4f for uncontrolled random phases.' % (md.ZETA, md.ZETA_RAND))

B.h2('3.2 Data / materials')
B.para('No external dataset is used. Scenarios are generated synthetically: K users are drawn uniformly in a 400 m × 400 m area (60 m margin, 60 m minimum separation), the BS is at the origin, and the depot is at the area centre. The ten evaluation layouts use random seeds 0–9 for K = 6 and the fleet-scaling study uses seeds 0–4 for K = 8. The M2 agent is trained only on layouts with different seeds (random draws during PPO, and 120 layouts with seeds 100–219 for behaviour cloning), so evaluation layouts are unseen. No human or animal subjects are involved. Table 2 lists the parameters; the propulsion parameters are those of ⟦3⟧.')
B.caption_above('Table 2.', 'Simulation parameters.')
rows = [['Area, duration, slots', '400 m × 400 m; T = %d s; N = %d (δ = %.0f s)' % (P['T'], P['N'], P['delta'])],
        ['UAV altitude, max speed', 'H = %.0f m (+10 m per additional UAV); V~max~ = %.0f m/s' % (P['H'], P['Vmax'])],
        ['Carrier, bandwidth, noise figure', '3.5 GHz; B = 1 MHz; 7 dB (σ^2^ = −107 dBm)'],
        ['BS', 'Height 25 m; antenna gain 15 dBi; P~max~ = %.2f W; ξ = %.1f' % (P['Pmax'], P['xi_pa'])],
        ['IRS', 'M = %d elements; b = %d bits; P~e~ = %.0f mW per element' % (P['M'], P['bits'], P['Pel'] * 1e3)],
        ['LoS model', 'Urban, a = 9.61, b = 0.16 ⟦1⟧; NLoS excess loss −20 dB'],
        ['Rotary-wing ⟦3⟧', 'P~0~ = 79.86 W; P~i~ = 88.63 W; U~tip~ = 120 m/s; v~0~ = 4.03 m/s; d~0~ = 0.6; ρ~a~ = 1.225; s = 0.05; A = 0.503 m^2^'],
        ['Rate floor, battery', 'R~min~ = 40 Mbit per user per mission (0.4 Mbps); M2 mission budget 15 kJ; endurance reference battery 0.3 kWh'],
        ['Outage, coverage', 'SNR threshold 0 dB; Gamma power fading, shape m = 4 (300 draws)']]
B.table(['Parameter', 'Value'], rows, [2.4, 6.4])

B.h2('3.3 Proposed approach')
B.para('Figure 1 shows the system and the three methodologies. All three share the channel, energy and metric code, so differences in results come only from the decision procedure.')
B.figure('figs/fig1_architecture.png', 15.5, 'Figure 1.', 'System model (a) and the proposed methodologies (b). BS: base station; IRS: intelligent reflecting surface; LoS: line of sight; LP: linear programme; SCA: successive convex approximation; PPO: proximal policy optimisation; BC: behaviour cloning; CSI: channel state information; EE: energy efficiency (bit/J).')
B.para('**M1: joint alternating optimisation.** Each outer iteration (i) sets the IRS phases in closed form, (ii) solves the time-share linear programme for fixed trajectory, which maximises delivered bits subject to the rate floors (with penalised slack so infeasible iterates are detectable), and (iii) refines the trajectory by one convex programme. With the Dinkelbach parameter λ equal to the current EE, step (iii) maximises')
B.equation(r'\sum_{n,k}\delta\,\rho_{n,k}R^{\mathrm{lb}}_{n,k}(\mathbf{q})-\lambda\sum_{n}\delta P^{\mathrm{ub}}_{\mathrm{prop},n}(\mathbf{q})', 6)
B.para('where R^lb^ is a concave lower bound of (2) obtained from the convexity of log~2~(1 + a e^−u^) in u = ln d~1~^2^ + ln d~2~^2^ and the concavity of the logarithm, and P^ub^ is a convex upper bound of (3) obtained with the auxiliary-variable reformulation of the induced-power term used in ⟦3⟧ and a tangent bound on the squared speed. A trust region and a backtracking acceptance test on the true EE make the iteration monotone. Transmit power is fixed at P~max~ in M1 and M3 (M2 controls it). The initial point is a nearest-neighbour tour through the users at constant speed, and the iteration stops when the relative gain falls below 10^−3^ twice.')
B.para('**M2: PPO with a battery constraint.** The agent observes its position relative to the depot, the remaining time and battery fraction, the user positions relative to the UAV, each user\'s remaining demand, its previous velocity, and per-user channel quality (log-rate at full power). It outputs a velocity, a transmit-power fraction and K logits whose softmax is the IRS time-share over users. The reward in slot n is')
B.equation(r'r_{n}=10^{-6}\Big(\sum_{k}b_{n,k}-\lambda_{0}e_{n}+\mu\sum_{k}\Delta\min(B_{k},R_{\min})\Big)', 7)
B.para('with b~n,k~ the bits delivered, e~n~ the slot energy, λ~0~ = 28 kbit/J the Dinkelbach reference, μ = 0.5 a progress bonus toward each user\'s demand, and B~k~ the cumulative bits. A terminal penalty of 60 per unit of unmet demand, and a penalty of 300 with termination if the 15 kJ battery budget is exceeded, complete the reward. A safety shield replaces any action that would make return to the depot infeasible within the remaining time, so the trajectory constraint holds by construction. Training from random initialisation did not satisfy the rate floors (not shown), so the final agent is warm-started by behaviour cloning on 120 M1 solutions from training layouts and then fine-tuned with PPO.')
B.para('**M3: multi-UAV cooperative scheduling.** U UAV-IRS nodes, each fed by its own co-channel BS, serve the same K users. An IRS aligned to its own user reaches other users incoherently, with gain reduced by the factor ζ~rand~/ζ, so the SINR of UAV i serving user k~i~ is')
B.equation(r'\gamma_{n,i}=\frac{p\,g^{(i)}_{n,k_{i}}}{\sigma^{2}+\sum_{j\neq i}p\,\tfrac{\zeta_{\mathrm{rand}}}{\zeta}\,g^{(j)}_{n,k_{i}}}', 8)
B.para('In each slot a joint mode assigns to every UAV one of its three best users or idleness; duplicate users are excluded. A linear programme over the time-share of each mode in each slot maximises delivered bits subject to the rate floors, which solves user association (a user may be served by several UAVs) and interference coordination together. The trajectory of each UAV is then refined with the M1 step, using its marginal time-shares and the bits delivered by the other UAVs, and the two stages alternate until convergence. UAVs fly at different altitudes in lieu of collision avoidance.')

B.h2('3.4 Experimental setup')
B.para('Experiments ran on a two-core cloud virtual machine with Python 3.13, NumPy, SciPy (HiGHS linear programmes), CVXPY 1.9.3 with the Clarabel solver, and PyTorch 2.14.1 (CPU). The code is deterministic given the seed. Baselines are (a) a static hover at the best grid position (19 × 19 grid, with transit legs from the depot added), (b) the nearest-neighbour tour with optimal time-shares, and, in ablations, M1 with uncontrolled random IRS phases and with b ∈ {1, 2, 3, 4, ∞} bit phase shifters. The M2 network has two 128-unit tanh layers for the policy and the critic, was cloned for 400 epochs, and fine-tuned for 3,000 PPO updates (16 parallel episodes of 100 steps each, learning rate 10^−4^, clip 0.2, discount 0.995, GAE 0.95, action standard deviation 0.14–0.20) with the mean action used at test time. Metrics are EE (bit/J); propulsion plus communication energy (J); sum rate and minimum per-user rate (delivered bits divided by T); outage probability (fraction of time-share-weighted active links with SNR below 0 dB under Gamma fading, shape 4); coverage fraction (fraction of user-slot pairs whose interference-free full-power SNR is at least 0 dB); endurance (0.3 kWh divided by mean power); trajectory length; outer iterations to convergence; and Jain\'s index of delivered bits. Values are mean ± standard deviation over the ten layouts (five for scaling); EE differences from M1 are tested with paired t-tests and reported with Cohen\'s d~z~. A run counts as feasible if the minimum user receives at least 99.5%% of R~min~.' % () if False else
       'Experiments ran on a two-core cloud virtual machine with Python 3.13, NumPy, SciPy (HiGHS linear programmes), CVXPY 1.9.3 with the Clarabel solver, and PyTorch 2.14.1 (CPU). The code is deterministic given the seed. Baselines are (a) a static hover at the best grid position (19 × 19 grid, with transit legs from the depot added), (b) the nearest-neighbour tour with optimal time-shares, and, in ablations, M1 with uncontrolled random IRS phases and with b ∈ {1, 2, 3, 4, ∞} bit phase shifters. The M2 network has two 128-unit tanh layers for the policy and the critic, was cloned for 400 epochs, and fine-tuned for 3,000 PPO updates (16 parallel episodes of 100 steps each, learning rate 10^−4^, clip 0.2, discount 0.995, GAE 0.95, action standard deviation 0.14–0.20) with the mean action used at test time. Metrics are EE (bit/J); propulsion plus communication energy (J); sum rate and minimum per-user rate (delivered bits divided by T); outage probability (fraction of time-share-weighted active links with SNR below 0 dB under Gamma fading, shape 4); coverage fraction (fraction of user-slot pairs whose interference-free full-power SNR is at least 0 dB); endurance (0.3 kWh divided by mean power); trajectory length; outer iterations to convergence; and Jain\'s index of delivered bits. Values are mean ± standard deviation over the ten layouts (five for scaling); EE differences from M1 are tested with paired t-tests and reported with Cohen\'s d~z~. A run counts as feasible if the minimum user receives at least 99.5% of R~min~.')

# ------------------------------------------------------------ 4 Results
B.h1('4. Results')
B.h2('4.1 Method comparison on identical layouts')
B.para('Table 3 and Figure 3 compare the methods on the ten six-user layouts, and Table 4 gives the remaining metrics. M1 achieved %s kbit/J while meeting every user\'s rate floor in all ten layouts. This is %.1f%% above the nearest-neighbour tour (%s kbit/J; paired t-test p %s, d~z~ = %.1f) and %.0f%% above the best static hover, which was infeasible in all layouts because no single position serves all six users (%s kbit/J). Figure 2 shows that M1 deviates from the tour by bending the path towards positions with a favourable product of BS-IRS and IRS-user distances; its path is longer (%s m against %s m), yet its propulsion energy is lower (%s kJ against %s kJ), because its mean speed of %.1f m/s lies close to the minimum-power speed of the rotary-wing model (about 10 m/s).' % (
    f('M1', 'EE', 1, 1e3), S['M1_vs_tour_pct'], f('tour', 'EE', 1, 1e3), pv(S['tour']['p_vs_M1']), abs(S['tour']['cohen_dz']), S['M1_vs_hover_pct'], f('hover', 'EE', 1, 1e3),
    mean('M1', 'traj_len', 0), mean('tour', 'traj_len', 0), mean('M1', 'E_prop', 2, 1e3), mean('tour', 'E_prop', 2, 1e3), mu_speed))
B.para('The M2 agent reached %s kbit/J, %.1f%% below M1 (p %s, d~z~ = %.1f). It never exceeded the battery budget (%d of %d layouts completed), but it also met the rate floor in none of them: the least-served user received on average %.0f%% of the demanded rate (Table 3). Its trajectory (Figure 2) is smooth but loops wastefully. M3 with two UAVs achieved %s kbit/J, which does not differ significantly from M1 (%.1f%%, p = %.2f), while delivering %.2f times its sum rate, covering %.0f%% of user-slot pairs against %.0f%% and keeping outage at %.3f.' % (
    f('M2', 'EE', 1, 1e3), abs(S['M2']['rel_vs_M1_pct']), pv(S['M2']['p_vs_M1']), abs(S['M2']['cohen_dz']), S['M2']['battery_ok'], n_test, m2_min_frac,
    f('M3', 'EE', 1, 1e3), S['M3']['rel_vs_M1_pct'], S['M3']['p_vs_M1'], sum_ratio, 100 * S['M3']['coverage'][0], 100 * S['M1']['coverage'][0], S['M3']['outage'][0]))
B.caption_above('Table 3.', 'Performance comparison against baselines on ten identical six-user layouts. Values are mean ± standard deviation over n = 10 runs; p-values are paired t-tests of EE against M1. Best feasible result in bold.')
def row(k, name, bold=False):
    r = [name, f(k, 'EE', 1, 1e3), f(k, 'sum_rate', 2, 1e6), f(k, 'min_rate', 3, 1e6), f(k, 'outage', 3), '%d/10' % S[k]['rmin_ok'], '—' if k == 'M1' else pv(S[k]['p_vs_M1'])]
    if bold: r[1] = '**%s**' % r[1]
    return r
rows3 = [row('hover', 'Static hover'), row('tour', 'Nearest-neighbour tour'), row('M1', 'M1 alternating optimisation', True),
         row('M2', 'M2 BC + PPO'), row('M3', 'M3 multi-UAV (U = 2)')]
B.table(['Method', 'EE (kbit/J)', 'Sum rate (Mbps)', 'Min user rate (Mbps)', 'Outage', 'Rate floor met', 'p-value'], rows3, [2.5, 1.4, 1.35, 1.5, 1.0, 1.0, 0.9], align=['left'] + ['center'] * 6, bold_rows=(2,))
B.figure('figs/fig2_trajectories.png', 15.5, 'Figure 2.', 'Trajectories on two evaluation layouts (scenarios 0 and 3). Axes are horizontal coordinates in metres. The BS is at the origin and all UAVs start and end at the depot (square). The dotted grey line is the initial tour, the solid blue line M1, the dashed orange line M2 and the purple lines the two UAVs of M3.')
B.figure('figs/fig3_performance.png', 15.5, 'Figure 3.', 'Energy efficiency (kbit/J), sum rate (Mbps) and minimum per-user rate (Mbps) by method. Bars are means over ten layouts and error bars are one standard deviation; the red dashed line is the per-user rate floor R~min~ (0.4 Mbps average).')
B.caption_above('Table 4.', 'Additional metrics (mean ± standard deviation over n = 10 layouts). Iterations are outer iterations to convergence.')
def row4(k, name):
    it = '%.1f ± %.1f' % tuple(S[k]['iters']) if 'iters' in S[k] else '—'
    return [name, f(k, 'E_tot', 2, 1e3), f(k, 'endurance_h', 2), f(k, 'traj_len', 0), f(k, 'coverage', 2), f(k, 'jain', 2), it]
B.table(['Method', 'Energy (kJ)', 'Endurance (h)', 'Path (m)', 'Coverage', 'Jain index', 'Iterations'],
        [row4('hover', 'Static hover'), row4('tour', 'Tour'), row4('M1', 'M1'), row4('M2', 'M2'), row4('M3', 'M3 (U = 2)')],
        [2.0, 1.4, 1.4, 1.3, 1.2, 1.2, 1.3], align=['left'] + ['center'] * 6)
B.para('Table 4 shows that endurance is almost identical for M1, M3 and the tour (about 2.3 h), because propulsion dominates: communication and IRS energy are only %.1f%% of M1\'s total (%.0f J of %.0f J). The static hover has the shortest path by definition but the lowest endurance (%s h) as it flies at the highest-power operating point.' % (Ecomm_share, S['M1']['E_comm'][0], S['M1']['E_tot'][0], mean('hover', 'endurance_h')))

B.h2('4.2 Convergence and ablations')
B.para('M1 converged in %.1f ± %.1f outer iterations and M3 in %.1f ± %.1f (Figure 4, left); most of the gain arrives in the first five iterations. M2 required a one-off behaviour-cloning stage plus 3,000 PPO updates (4.8 million environment steps). Fine-tuning moved the cloned policy from %d of ten layouts completing within the battery budget to ten of ten, and lifted the worst-served user\'s training-time demand coverage from about 4%% to about 45%%, but the training EE plateaued near 22 kbit/J (Figure 4, right), well below M1. The cloned policy alone reached %s kbit/J with large variance and met the rate floor in none of the layouts.' % (
    S['M1']['iters'][0], S['M1']['iters'][1], S['M3']['iters'][0], S['M3']['iters'][1], bc_batt, f('M2_bc', 'EE', 1, 1e3)))
B.figure('figs/fig4_convergence.png', 15.5, 'Figure 4.', 'Convergence. Left: energy efficiency (kbit/J) against outer iteration for M1 and M3 (U = 2), mean ± standard deviation over ten layouts, with converged runs held at their final value. Right: PPO fine-tuning, training-layout EE (kbit/J) per update and 20-update moving average; the dashed line is the M1 test mean.')
B.para('Figure 5 isolates the IRS. With uncontrolled random phases, and the same M1 trajectory, EE collapsed to %s kbit/J (%.0f%% lower) and no layout was feasible, since the coherent gain M^2^ is replaced by M. With phase control, EE grew with resolution: 2-bit shifters (the default) gave %s kbit/J, 3-bit %s, 4-bit %s and continuous phases %s kbit/J, so the default loses %.1f%% against ideal phases; 1-bit shifters (%s kbit/J) were infeasible in all ten layouts.' % (
    f('M1_randphase', 'EE', 1, 1e3), 100 * (1 - S['M1_randphase']['EE'][0] / S['M1']['EE'][0]),
    '%.1f' % (ph['M1_bits_2'][0] / 1e3), '%.1f' % (ph['M1_bits_3'][0] / 1e3), '%.1f' % (ph['M1_bits_4'][0] / 1e3), '%.1f' % (ph['M1_bits_None'][0] / 1e3), loss2, '%.1f' % (ph['M1_bits_1'][0] / 1e3)))
B.figure('figs/fig6_phase.png', 9.5, 'Figure 5.', 'Effect of IRS phase-shifter resolution on M1 energy efficiency (kbit/J). Points are means over ten layouts and error bars one standard deviation; the annotation reports the random-phase ablation, which is off the plotted range.')

B.h2('4.3 Multi-UAV scaling')
B.para('Table 5 and Figure 6 vary the fleet size U from one to four on five eight-user layouts. The coordinated scheduler met the rate floor in all %d runs for every U. Sum rate rose from %.2f to %.2f Mbps (%.1f times) while EE stayed near 30 kbit/J for one to three UAVs (%.1f, %.1f, %.1f kbit/J) and fell to %.1f kbit/J at four, where the demand floor was already met and additional UAVs add energy faster than useful bits. Coverage rose from %.2f to %.2f. Jain\'s index fell from %.2f (U = 1) to %.2f (U = 2) and then recovered to %.2f, because the objective maximises EE subject to floors, so surplus capacity goes to the best-placed users; fairness was not optimised. Without coordination (static association, independent per-UAV scheduling, all UAVs transmitting simultaneously, on the same trajectories) EE was %.1f, %.1f and %.1f kbit/J for U = 2, 3 and 4 and the rate floor was met in %d, %d and %d of five layouts. The EE difference was significant at U = 4 (paired p = %.3f) but not at U = 2 or 3 (p = %.2f and %.2f), which with five layouts is underpowered. The share of users served by more than one UAV rose from %.0f%% to %.0f%% as U grew from two to four.' % (
    sc['1']['n'], sc['1']['sum_rate'][0] / 1e6, sc['4']['sum_rate'][0] / 1e6, sc['4']['sum_rate'][0] / sc['1']['sum_rate'][0],
    sc['1']['EE'][0] / 1e3, sc['2']['EE'][0] / 1e3, sc['3']['EE'][0] / 1e3, sc['4']['EE'][0] / 1e3,
    sc['1']['coverage'][0], sc['4']['coverage'][0], sc['1']['jain'][0], sc['2']['jain'][0], sc['4']['jain'][0],
    sc['2']['unc']['EE'][0] / 1e3, sc['3']['unc']['EE'][0] / 1e3, sc['4']['unc']['EE'][0] / 1e3,
    sc['2']['unc']['rmin_ok'], sc['3']['unc']['rmin_ok'], sc['4']['unc']['rmin_ok'],
    sc['4']['unc']['p_EE'], sc['2']['unc']['p_EE'], sc['3']['unc']['p_EE'], 100 * sc['2']['multi_served'][0], 100 * sc['4']['multi_served'][0]))
B.caption_above('Table 5.', 'Fleet scaling with K = 8 users (mean ± standard deviation over n = 5 layouts). Coord.: interference-aware joint scheduling; Uncoord.: independent scheduling on the same trajectories.')
rows5 = []
for U in ('1', '2', '3', '4'):
    d = sc[U]; u = d.get('unc')
    rows5.append([U, '%.1f ± %.1f' % (d['EE'][0] / 1e3, d['EE'][1] / 1e3), '%.2f ± %.2f' % (d['sum_rate'][0] / 1e6, d['sum_rate'][1] / 1e6), '%.2f ± %.2f' % tuple(d['jain']),
                  '%.2f ± %.2f' % tuple(d['coverage']), '%d/5' % d['rmin_ok'],
                  ('%.1f ± %.1f' % (u['EE'][0] / 1e3, u['EE'][1] / 1e3)) if u else '—', ('%d/5' % u['rmin_ok']) if u else '—'])
B.table(['U', 'EE coord. (kbit/J)', 'Sum rate (Mbps)', 'Jain index', 'Coverage', 'Floor met', 'EE uncoord. (kbit/J)', 'Floor met'], rows5,
        [0.5, 1.6, 1.5, 1.3, 1.3, 0.9, 1.7, 0.9], align=['center'] * 8)
B.figure('figs/fig5_scaling.png', 16.0, 'Figure 6.', 'Effect of fleet size U (K = 8 users) on energy efficiency, sum rate, Jain\'s index and minimum user rate. Points are means over five layouts and error bars one standard deviation. Solid green: coordinated scheduling; dashed grey: uncoordinated scheduling on the same trajectories (U ≥ 2). The dotted red line marks the rate floor.')

# ------------------------------------------------------------ 5 Discussion
B.h1('5. Discussion')
B.para('The main result is that for this scenario structured optimisation is the strongest single-UAV method, and the reasons are mechanistic. Propulsion accounts for %.0f%% of the energy, so EE is governed by flying near the minimum-power speed while visiting positions where the cascaded gain is high; M1 optimises exactly that trade-off with the model in hand, and the closed-form IRS phases make the channel side tractable. The IRS ablation shows what the passive surface contributes: coherent alignment is worth an order of magnitude in EE, and phase resolution matters only until about two to three bits.' % (100 - Ecomm_share))
B.para('The comparison with prior work is necessarily qualitative, because earlier studies use different scenarios. The EE-oriented optimisation studies ⟦17,18⟧ use the same family of tools as M1 and our M1 behaves as that literature would lead one to expect, with monotone convergence in a few tens of iterations. Learning-based studies ⟦22,27,29,30⟧ are attractive when models are uncertain or the problem is hard to decompose; here the model is known and the subproblems are convex, which is a plausible reason why M2 does not beat M1. We did not test model mismatch, where the ranking could reverse, and we make no claim that M2 is intrinsically inferior: its failure to meet the rate floors points to the difficulty of constraint handling with a sparse terminal penalty and 120 demonstrations.')
B.para('For practice, three points follow. First, hovering is a poor operating mode for a rotary-wing relay (%s%% lower EE than M1), so mobility should be treated as an energy-saving resource rather than a cost. Second, low-resolution IRS hardware of two bits retains about %.0f%% of the continuous-phase EE, which supports cheap phase shifters. Third, fleet size should follow demand: in our scenario one UAV sufficed for the rate floors, and additional UAVs raised capacity and coverage at the price of lower EE once the floors were met; when interference is possible, joint scheduling is what keeps the floors satisfied.' % ('%.0f' % (100 * (1 - S['hover']['EE'][0] / S['M1']['EE'][0])), 100 - loss2))
B.para('Limitations should be read alongside the results. (i) The channel is a synthetic large-scale model with a LoS-probability term; there is no measured data, small-scale fading enters only the outage estimate, and the direct BS-user link is ignored, which probably overstates the IRS contribution at close range. (ii) The scheduler and M1 assume perfect channel knowledge, and IRS reconfiguration overhead and channel-estimation cost are not modelled. (iii) There are ten layouts for single-UAV comparisons and five for scaling; the uncoordinated ablation reuses coordinated trajectories and so isolates scheduling only, and several scaling comparisons are underpowered. (iv) M2 was trained with one seed and a modest budget and did not meet the rate floors, so its EE is not a like-for-like feasible result and likely understates what a constrained-RL method could achieve. (v) M1 and M3 find local optima of a non-convex problem, with no optimality gap computed. (vi) Collision avoidance among UAVs is replaced by altitude separation. (vii) EE is dominated by propulsion by construction; a scenario with a larger IRS or multi-antenna BS would shift this balance. Each of these would, if addressed, most likely change the absolute numbers rather than the ordering of M1 over the tour and the dependence on IRS phase control, but this has not been verified.')

# ------------------------------------------------------------ 6 Conclusion
B.h1('6. Conclusion')
B.para('This study compared alternating optimisation (M1), a battery-constrained PPO agent (M2) and cooperative multi-UAV scheduling (M3) for energy-efficient UAV-mounted IRS communication, on identical synthetic scenarios. M1 reached %s kbit/J, %.1f%% above a tour baseline, while meeting all rate floors; random IRS phases lowered EE by %.0f%%, and 2-bit phase shifters cost %.1f%% against ideal phases. The M2 agent respected the battery budget but reached %s kbit/J and did not meet the rate floors. Two cooperating UAVs delivered %.2f times the sum rate at statistically indistinguishable EE, and EE fell at a fleet of four once demand was saturated. This contributes a reproducible, like-for-like benchmark showing where optimisation, learning and fleet scaling each help in a propulsion-aware IRS-UAV system. Future work will add a constrained-RL formulation with a learned Lagrange multiplier for M2, evaluate all methods under imperfect CSI and measured channels, and add a fairness-aware objective to M3.' % (
    f('M1', 'EE', 1, 1e3), S['M1_vs_tour_pct'], 100 * (1 - S['M1_randphase']['EE'][0] / S['M1']['EE'][0]), loss2, f('M2', 'EE', 1, 1e3), sum_ratio))

# ------------------------------------------------------------ declarations
B.h1('Declarations')
B.declaration('Acknowledgements.', '==[To be completed by the authors.]==')
B.declaration('Funding.', '==[Grant name and number, or: This research received no specific grant from any funding agency.]==')
B.declaration('Conflict of interest.', '==[To be completed by the authors.]==')
B.declaration('Data availability.', 'All results are generated by the simulation code (model, M1, M2, M3 and evaluation scripts) with fixed random seeds, supplied with this draft; ==[repository DOI to be added]==. No external dataset was used.')
B.declaration('Author contributions.', '==[Use CRediT terms: conceptualisation, methodology, software, validation, formal analysis, investigation, writing – original draft, writing – review and editing, supervision.]==')
B.declaration('Use of AI tools.', 'The simulation code, analysis and first draft of this manuscript were produced with the assistance of Claude (Anthropic) under the authors\' direction. ==[Authors to confirm and adapt to the target journal\'s AI-use policy; all numbers should be re-run and verified by the authors.]==')

# ------------------------------------------------------------ references
B.h1('References')
for sid, num in sorted(B.cites.items(), key=lambda x: x[1]):
    B.ref(num, REF[sid]['text'])
uncited = [k for k in REF if k not in B.cites]
print('uncited refs:', uncited, 'n refs', len(B.cites))
B.save('out/Energy_Aware_IRS_UAV_Manuscript.docx')
