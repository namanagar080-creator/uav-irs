import pickle, json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
import model as md
from model import P, BS_POS, DEPOT

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.alpha': 0.25, 'grid.linewidth': 0.5})
NAVY, BLUE, ORG, GRN, GREY = '#1F3864', '#2F5597', '#C55A11', '#548235', '#7F7F7F'
cmp_ = pickle.load(open('out/compare.pkl', 'rb'))
scl = pickle.load(open('out/scaling.pkl', 'rb'))
m2s = json.load(open('out/m2_summary2.json'))
S = len(cmp_)


def arr(key, met):
    return np.array([r[key][met] for r in cmp_], float)


methods = [('hover', 'Hover'), ('tour', 'Tour'), ('M1', 'M1'), ('M2', 'M2'), ('M3', 'M3 (U=2)')]
out = {}

# ---------- Fig 2 trajectories
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), dpi=300)
for ax, sd in zip(axs, (0, 3)):
    r = cmp_[sd]; u = r['users']
    ax.plot(*BS_POS[0], marker='^', color=NAVY, ms=7, ls='none', label='BS')
    ax.plot(*DEPOT, marker='s', color='k', ms=5, ls='none', label='Depot')
    ax.plot(u[:, 0], u[:, 1], 'o', color=GRN, ms=5, label='Users')
    for key, nm, c, ls in (('q_tour', 'Initial tour', GREY, ':'), ('q_M1', 'M1', BLUE, '-'), ('q_M2', 'M2', ORG, '--')):
        q = np.vstack([DEPOT, r[key]]); ax.plot(q[:, 0], q[:, 1], color=c, ls=ls, lw=1.2, label=nm)
    for i in range(2):
        q = np.vstack([DEPOT, r['Q_M3'][i]]); ax.plot(q[:, 0], q[:, 1], color='#7030A0', ls=('-.' if i == 0 else (0, (1, 1))), lw=1.1, label='M3 UAV %d' % (i + 1))
    ax.set_xlim(-10, 410); ax.set_ylim(-10, 410); ax.set_aspect('equal')
    ax.set_xlabel('x (m)'); ax.set_ylabel('y (m)'); ax.set_title('Scenario %d' % sd, fontsize=8.5)
axs[0].legend(fontsize=6, loc='upper right', ncol=2, framealpha=0.9)
fig.tight_layout(); fig.savefig('figs/fig2_trajectories.png', dpi=300); plt.close(fig)

# ---------- Fig 3 performance bars
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), dpi=300)
cols = [GREY, '#A5A5A5', BLUE, ORG, GRN]; hat = ['', '//', '', '\\\\', 'xx']
for ax, (met, lab, sc) in zip(axs, (('EE', 'Energy efficiency (kbit/J)', 1e3), ('sum_rate', 'Sum rate (Mbps)', 1e6), ('min_rate', 'Min per-user rate (Mbps)', 1e6))):
    mu = [arr(k, met).mean() / sc for k, _ in methods]; sd = [arr(k, met).std(ddof=1) / sc for k, _ in methods]
    ax.bar(range(5), mu, yerr=sd, color=cols, edgecolor='k', lw=0.5, capsize=2.5, hatch=None)
    for i, h in enumerate(hat):
        ax.patches[i].set_hatch(h)
    ax.set_xticks(range(5)); ax.set_xticklabels([n for _, n in methods], rotation=30, ha='right', fontsize=7)
    ax.set_ylabel(lab)
    if met == 'min_rate': ax.axhline(P['Rmin'] / P['T'] / 1e6, color='r', lw=0.9, ls='--'); ax.text(4.4, P['Rmin'] / P['T'] / 1e6 * 1.05, 'R$_{min}$', color='r', fontsize=7, ha='right')
fig.tight_layout(); fig.savefig('figs/fig3_performance.png', dpi=300); plt.close(fig)

# ---------- Fig 4 convergence
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7), dpi=300)
L = max(len(r['M1']['hist']) for r in cmp_)
H = np.full((S, L), np.nan)
for i, r in enumerate(cmp_):
    h = np.array(r['M1']['hist']) / 1e3; H[i, :len(h)] = h; H[i, len(h):] = h[-1]
ax = axs[0]; it = np.arange(L)
ax.plot(it, H.mean(0), color=BLUE, lw=1.4, label='M1 mean (10 scenarios)'); ax.fill_between(it, H.mean(0) - H.std(0, ddof=1), H.mean(0) + H.std(0, ddof=1), color=BLUE, alpha=0.2)
L3 = max(len(r['M3']['hist']) for r in cmp_); H3 = np.full((S, L3), np.nan)
for i, r in enumerate(cmp_):
    h = np.array(r['M3']['hist']) / 1e3; H3[i, :len(h)] = h; H3[i, len(h):] = h[-1]
ax.plot(np.arange(L3), H3.mean(0), color=GRN, lw=1.4, ls='--', label='M3, U=2 mean'); ax.fill_between(np.arange(L3), H3.mean(0) - H3.std(0, ddof=1), H3.mean(0) + H3.std(0, ddof=1), color=GRN, alpha=0.2)
ax.set_xlabel('Outer iteration'); ax.set_ylabel('Energy efficiency (kbit/J)'); ax.legend(fontsize=6.5)
ax = axs[1]
cv = m2s['curve']; ee = np.array([c['EE'] for c in cv]) / 1e3; k = 20
ma = np.convolve(ee, np.ones(k) / k, mode='valid')
ax.plot(ee, color=ORG, alpha=0.25, lw=0.7, label='penalty PPO, per update'); ax.plot(np.arange(k - 1, len(ee)), ma, color=ORG, lw=1.4, label='penalty PPO, moving avg (20)')
import glob as _g
_L = [json.load(open(p))['curve'] for p in sorted(_g.glob('out/m2L_s*.json'))]
if _L:
    n_ = min(len(c) for c in _L); E_ = np.array([[c[i]['EE'] for i in range(n_)] for c in _L]) / 1e3
    mm = np.convolve(E_.mean(0), np.ones(k) / k, mode='valid')
    ax.plot(np.arange(k - 1, n_), mm, color='#7030A0', lw=1.3, ls='-.', label='constrained PPO (mean of %d seeds)' % len(_L))
ax.axhline(arr('M1', 'EE').mean() / 1e3, color=BLUE, ls='--', lw=1, label='M1 (test mean)')
ax.set_xlabel('PPO update (fine-tuning)'); ax.set_ylabel('Training EE (kbit/J)'); ax.legend(fontsize=5.8, loc='lower right')
fig.tight_layout(); fig.savefig('figs/fig4_convergence.png', dpi=300); plt.close(fig)

# ---------- Fig 5 scaling
Us = [1, 2, 3, 4]; seeds = sorted(set(r['seed'] for r in scl))
def sget(U, met, key='m'):
    v = []
    for r in scl:
        if r['U'] == U and r[key] is not None: v.append(r[key][met])
    return np.array(v, float)
fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.4), dpi=300)
specs = [('EE', 'Energy eff. (kbit/J)', 1e3), ('sum_rate', 'Sum rate (Mbps)', 1e6), ('jain', "Jain's index", 1), ('min_rate', 'Min user rate (Mbps)', 1e6)]
for ax, (met, lab, sc) in zip(axs, specs):
    mu = [sget(U, met).mean() / sc for U in Us]; sd = [sget(U, met).std(ddof=1) / sc for U in Us]
    ax.errorbar(Us, mu, yerr=sd, color=GRN, marker='o', ms=4, lw=1.3, capsize=2.5, label='Coordinated')
    Uu = [2, 3, 4]
    mu2 = [sget(U, met, 'unc').mean() / sc for U in Uu]; sd2 = [sget(U, met, 'unc').std(ddof=1) / sc for U in Uu]
    ax.errorbar(Uu, mu2, yerr=sd2, color=GREY, marker='s', ms=3.5, lw=1.1, ls='--', capsize=2.5, label='Uncoordinated')
    ax.set_xlabel('Fleet size U'); ax.set_ylabel(lab); ax.set_xticks(Us)
    if met == 'min_rate': ax.axhline(P['Rmin'] / P['T'] / 1e6, color='r', lw=0.8, ls=':')
axs[0].legend(fontsize=6)
fig.tight_layout(); fig.savefig('figs/fig5_scaling.png', dpi=300); plt.close(fig)

# ---------- Fig 6 phase resolution
fig, ax = plt.subplots(figsize=(3.6, 2.5), dpi=300)
bl = ['1', '2', '3', '4', '$\\infty$']; keys = ['M1_bits_1', 'M1_bits_2', 'M1_bits_3', 'M1_bits_4', 'M1_bits_None']
mu = [arr(k, 'EE').mean() / 1e3 for k in keys]; sd = [arr(k, 'EE').std(ddof=1) / 1e3 for k in keys]
ax.errorbar(range(5), mu, yerr=sd, color=BLUE, marker='o', ms=4, capsize=2.5, lw=1.3)
ax.set_xticks(range(5)); ax.set_xticklabels(bl); ax.set_xlabel('IRS phase-shifter resolution b (bits)'); ax.set_ylabel('Energy efficiency (kbit/J)')
mr = arr('M1_randphase', 'EE').mean() / 1e3
ax.text(1.0, 21.5, 'random phases (no IRS control):\nEE = %.1f kbit/J, min-rate met in %d/10' % (mr, sum(r['M1_randphase']['rmin_ok'] for r in cmp_)), fontsize=6.5, color=ORG)
fig.tight_layout(); fig.savefig('figs/fig6_phase.png', dpi=300); plt.close(fig)

# ---------- summary numbers
def ms(a): return '%.2f ± %.2f' % (np.mean(a), np.std(a, ddof=1))
summ = {}
for k, n in methods + [('M2_bc', 'M2 BC-only'), ('M3_uncoord', 'M3 uncoord'), ('M1_randphase', 'M1 randphase')]:
    summ[k] = {m: (float(arr(k, m).mean()), float(arr(k, m).std(ddof=1))) for m in ('EE', 'sum_rate', 'min_rate', 'jain', 'outage', 'coverage', 'E_tot', 'E_prop', 'E_comm', 'endurance_h', 'traj_len')}
    summ[k]['rmin_ok'] = int(sum(r[k]['rmin_ok'] for r in cmp_))
    if k == 'M2': summ[k]['battery_ok'] = int(sum(r[k]['battery_ok'] for r in cmp_))
for k in ('hover', 'tour', 'M2', 'M3', 'M2_bc', 'M3_uncoord'):
    a, b = arr(k, 'EE'), arr('M1', 'EE')
    t, p = stats.ttest_rel(a, b); d = a - b
    summ[k]['p_vs_M1'] = float(p); summ[k]['cohen_dz'] = float(d.mean() / d.std(ddof=1)); summ[k]['rel_vs_M1_pct'] = float(100 * (a.mean() / b.mean() - 1))
summ['M1']['iters'] = (float(np.mean([r['M1']['iters'] for r in cmp_])), float(np.std([r['M1']['iters'] for r in cmp_], ddof=1)))
summ['M3']['iters'] = (float(np.mean([r['M3']['iters'] for r in cmp_])), float(np.std([r['M3']['iters'] for r in cmp_], ddof=1)))
summ['M1_vs_tour_pct'] = float(100 * (arr('M1', 'EE').mean() / arr('tour', 'EE').mean() - 1))
summ['M1_vs_hover_pct'] = float(100 * (arr('M1', 'EE').mean() / arr('hover', 'EE').mean() - 1))
summ['phase'] = {k: (float(arr(k, 'EE').mean()), float(arr(k, 'EE').std(ddof=1))) for k in keys}
summ['phase_rmin_ok'] = {k: int(sum(r[k]['rmin_ok'] for r in cmp_)) for k in keys}
# M2 convergence
cv = np.array([c['EE'] for c in m2s['curve']]); ma = np.convolve(cv, np.ones(20) / 20, mode='valid')
fin = ma[-20:].mean(); summ['M2_conv_updates'] = int(np.argmax(ma >= 0.95 * fin) + 19)
summ['M2_bc_ee_per_seed'] = [b['EE'] for b in m2s['before']]
# scaling summary
summ['scaling'] = {}
for U in Us:
    d = {}
    for met in ('EE', 'sum_rate', 'min_rate', 'jain', 'outage', 'coverage', 'E_tot', 'endurance_h', 'traj_len', 'multi_served'):
        v = sget(U, met); d[met] = (float(v.mean()), float(v.std(ddof=1)))
    d['iters'] = (float(sget(U, 'iters').mean()), float(sget(U, 'iters').std(ddof=1)))
    d['rmin_ok'] = int(sum(1 for r in scl if r['U'] == U and r['m']['rmin_ok'])); d['n'] = int(sum(1 for r in scl if r['U'] == U))
    if U > 1:
        du = {}
        for met in ('EE', 'sum_rate', 'min_rate', 'jain'):
            v = sget(U, met, 'unc'); du[met] = (float(v.mean()), float(v.std(ddof=1)))
        du['rmin_ok'] = int(sum(1 for r in scl if r['U'] == U and r['unc']['rmin_ok']))
        a, b = sget(U, 'EE'), sget(U, 'EE', 'unc'); t, p = stats.ttest_rel(a, b); du['p_EE'] = float(p)
        d['unc'] = du
    summ['scaling'][U] = d
json.dump(summ, open('out/summary.json', 'w'), indent=1, default=float)
print(json.dumps(summ, indent=1, default=float)[:6000])
