"""M2 - DRL trajectory learning (PPO) with battery constraint.
One policy controls UAV velocity, BS transmit-power fraction and the IRS phase configuration
(softmax time-share over which user the IRS is phase-aligned to) as ONE sequential decision problem.
Reward is the Dinkelbach form  (bits - lam0*energy)/1e6  with lam0 = reference EE (bits/J),
plus terminal penalties (unmet per-user demand, battery overrun).  A safety shield guarantees the UAV
can always return to the depot within the remaining time (so the trajectory constraint is always met).
"""
import numpy as np, torch, torch.nn as nn, time, sys, json
import model as md
from model import P, BS_POS, DEPOT

K = 6
MU = 0.5
LAM0 = 28000.0           # Dinkelbach reference (bits/J) ~ M1 operating point
OBS = 2 + 1 + 1 + 2 * K + K + 2 + K
ACT = 3 + K


def sample_users(rng, K=K, margin=60.0, min_sep=60.0):
    pts = []
    while len(pts) < K:
        c = rng.uniform(margin, P['area'] - margin, 2)
        if all(np.linalg.norm(c - p) > min_sep for p in pts):
            pts.append(c)
    return np.array(pts)


class Env:
    def __init__(self, n_env, rng, users=None):
        self.n = n_env; self.rng = rng; self.fixed = users
        self.bs = BS_POS[0]; self.H = P['H']
        self.C = md.Ccoef(True)
        self.lam = None

    def reset(self):
        n = self.n
        if self.fixed is not None:
            self.users = np.broadcast_to(self.fixed, (n, K, 2)).copy()
        else:
            self.users = np.stack([sample_users(self.rng) for _ in range(n)])
        self.pos = np.broadcast_to(DEPOT, (n, 2)).copy()
        self.vel = np.zeros((n, 2))
        self.t = 0
        self.bits = np.zeros((n, K)); self.E = np.zeros(n)
        self.alive = np.ones(n, bool)
        self.traj = [[] for _ in range(n)]; self.rhos = [[] for _ in range(n)]; self.pw = [[] for _ in range(n)]
        return self.obs()

    def csi(self):
        d1 = np.sum((self.pos - self.bs) ** 2, 1) + (self.H - P['Hb']) ** 2
        dd2 = self.pos[:, None, :] - self.users
        rh2 = np.sum(dd2 ** 2, 2); d2 = rh2 + self.H ** 2
        G = self.C * md.eta_iu(np.sqrt(rh2), self.H) / (d1[:, None] * d2)
        snr = P['Pmax'] * G / P['sigma2']
        if getattr(self, 'csi_sigma', 0.0) > 0:      # imperfect CSI: lognormal error on the gain the policy sees
            snr = snr * 10 ** (self.csi_sigma * self.rng.standard_normal(snr.shape) / 10)
        return (np.log2(1 + snr) - 6.0) / 3.0

    def obs(self):
        rel = (self.users - self.pos[:, None, :]) / P['area']
        dem = np.clip(1 - self.bits / P['Rmin'], 0, 1)
        o = np.concatenate([(self.pos - DEPOT) / P['area'], [[1 - self.t / P['N']]] * 1 if False else
                            np.full((self.n, 1), 1 - self.t / P['N']),
                            np.clip(1 - self.E / P['Emission'], -1, 1)[:, None],
                            rel.reshape(self.n, -1), dem, self.vel / P['Vmax'], self.csi()], 1)
        return o.astype(np.float32)

    def step(self, a):
        n = self.n; dl = P['delta']
        v = P['Vmax'] * np.tanh(a[:, 0:2])
        sp = np.linalg.norm(v, axis=1, keepdims=True)
        v = np.where(sp > P['Vmax'], v * P['Vmax'] / (sp + 1e-9), v)
        newp = np.clip(self.pos + v * dl, 0, P['area'])
        # --- safety shield: must be able to get back to depot in remaining steps
        rem_after = P['N'] - (self.t + 1)
        R = P['Vmax'] * dl * rem_after
        dd = newp - DEPOT; dn = np.linalg.norm(dd, axis=1, keepdims=True)
        proj = DEPOT + dd * np.minimum(1, R / (dn + 1e-9))
        dp = proj - self.pos; dpn = np.linalg.norm(dp, axis=1, keepdims=True)
        p2 = self.pos + dp * np.minimum(1, P['Vmax'] * dl / (dpn + 1e-9))
        ok = np.linalg.norm(p2 - DEPOT, axis=1, keepdims=True) <= R + 1e-6
        dh = DEPOT - self.pos; dhn = np.linalg.norm(dh, axis=1, keepdims=True)
        fb = self.pos + dh * np.minimum(1, P['Vmax'] * dl / (dhn + 1e-9))
        newp = np.where(ok, p2, fb)
        if rem_after == 0:
            newp = np.broadcast_to(DEPOT, newp.shape).copy()
        speed = np.linalg.norm(newp - self.pos, axis=1) / dl
        pfrac = 1 / (1 + np.exp(-a[:, 2]))
        z = a[:, 3:] - a[:, 3:].max(1, keepdims=True)
        rho = np.exp(z); rho /= rho.sum(1, keepdims=True)
        Ptx = pfrac * P['Pmax']
        d1 = np.sum((newp - self.bs) ** 2, 1) + (self.H - P['Hb']) ** 2
        dd2 = newp[:, None, :] - self.users
        rh2 = np.sum(dd2 ** 2, 2)
        d2 = rh2 + self.H ** 2
        G = self.C * md.eta_iu(np.sqrt(rh2), self.H) / (d1[:, None] * d2)
        rate = P['B'] * np.log2(1 + Ptx[:, None] * G / P['sigma2'])
        sb = dl * rho * rate
        e = dl * (md.prop_power(speed) + rho.sum(1) * Ptx / P['xi_pa'] + P['M'] * P['Pel'])
        al = self.alive
        prog = np.minimum(self.bits + sb, P['Rmin']) - np.minimum(self.bits, P['Rmin'])   # capped progress toward demand
        if self.lam is None:
            r = (sb.sum(1) - LAM0 * e + MU * prog.sum(1)) / 1e6
        else:   # Lagrangian: dense form of  -lam * sum_k shortfall_k  (shortfall in fractions of Rmin)
            r = (sb.sum(1) - LAM0 * e) / 1e6 + self.lam * prog.sum(1) / P['Rmin']
        r = np.where(al, r, 0.0)
        # record trajectory (for evaluation)
        for i in range(n):
            if al[i]:
                self.traj[i].append(newp[i].copy()); self.rhos[i].append(rho[i].copy()); self.pw[i].append(Ptx[i])
        self.bits += np.where(al[:, None], sb, 0)
        self.E += np.where(al, e, 0)
        self.vel = np.where(al[:, None], (newp - self.pos) , self.vel) / dl if False else (newp - self.pos) / dl
        self.pos = np.where(al[:, None], newp, self.pos)
        self.t += 1
        done = np.zeros(n, bool)
        # battery overrun -> terminate with penalty
        over = al & (self.E > P['Emission'])
        r = r - 300.0 * over
        self.alive = al & ~over
        if self.t >= P['N']:
            short = np.clip(1 - self.bits / P['Rmin'], 0, None).sum(1)
            if self.lam is None:
                r = r - 60.0 * short * self.alive
            done[:] = True
        done |= ~self.alive & True if False else False
        return self.obs(), r.astype(np.float32), done | (~self.alive), over


class AC(nn.Module):
    def __init__(self):
        super().__init__()
        self.pi = nn.Sequential(nn.Linear(OBS, 128), nn.Tanh(), nn.Linear(128, 128), nn.Tanh(), nn.Linear(128, ACT))
        self.v = nn.Sequential(nn.Linear(OBS, 128), nn.Tanh(), nn.Linear(128, 128), nn.Tanh(), nn.Linear(128, 1))
        self.logstd = nn.Parameter(torch.full((ACT,), -0.5), requires_grad=False)
        with torch.no_grad():
            self.pi[-1].weight.mul_(0.1); self.pi[-1].bias.zero_()
            self.pi[-1].bias[2] = 3.0       # start near full power

    def dist(self, o):
        return torch.distributions.Normal(self.pi(o), self.logstd.exp())


def evaluate_policy(net, users, seed=0, csi_sigma=0.0):
    env = Env(1, np.random.default_rng(seed), users=users)
    env.csi_sigma = csi_sigma
    o = env.reset()
    done = False
    while not done:
        with torch.no_grad():
            a = net.pi(torch.as_tensor(o)).numpy()
        o, r, d, over = env.step(a)
        done = bool(d[0])
    q = np.array(env.traj[0]); rho = np.array(env.rhos[0]); pw = np.array(env.pw[0])
    battery_ok = len(q) == P['N']
    if not battery_ok:   # terminated by battery: report as failure with partial data padded
        pad = P['N'] - len(q)
        q = np.vstack([q, np.tile(q[-1], (pad, 1))]); rho = np.vstack([rho, np.zeros((pad, K))]); pw = np.concatenate([pw, np.zeros(pad)])
    m = md.metrics_single(q, users, rho, pw)
    m['battery_ok'] = battery_ok
    return q, rho, pw, m


def train(n_updates=500, n_env=16, seed=0, log=None, test_users=None, net=None, std0=-0.5, std1=-1.5, lr=3e-4, lag=False, lam0=20.0, eta=3.0, tol=0.005):
    torch.manual_seed(seed); rng = np.random.default_rng(seed + 12345)
    net = AC() if net is None else net
    opt = torch.optim.Adam([p for p in net.parameters() if p.requires_grad], lr=lr)
    env = Env(n_env, rng)
    lam = lam0
    N = P['N']; gamma, lamb = 0.995, 0.95
    curve = []
    t0 = time.time()
    for upd in range(n_updates):
        with torch.no_grad():
            frac = min(1.0, upd / (0.8 * n_updates))
            net.logstd.copy_(torch.full((ACT,), std0 + (std1 - std0) * frac))
        if lag: env.lam = lam
        o = env.reset()
        O = np.zeros((N, n_env, OBS), np.float32); A = np.zeros((N, n_env, ACT), np.float32)
        LP = np.zeros((N, n_env), np.float32); R = np.zeros((N, n_env), np.float32)
        V = np.zeros((N + 1, n_env), np.float32); D = np.zeros((N, n_env), np.float32)
        alive_mask = np.ones((N, n_env), np.float32)
        for t in range(N):
            ot = torch.as_tensor(o)
            with torch.no_grad():
                dist = net.dist(ot); a = dist.sample()
                lp = dist.log_prob(a).sum(1); val = net.v(ot).squeeze(1)
            alive_mask[t] = env.alive
            o2, r, d, over = env.step(a.numpy())
            O[t] = o; A[t] = a.numpy(); LP[t] = lp.numpy(); R[t] = r; V[t] = val.numpy(); D[t] = d
            o = o2
        V[N] = 0
        # GAE with alive mask (dead envs contribute zero)
        adv = np.zeros((N, n_env), np.float32); last = 0
        for t in reversed(range(N)):
            nonterm = 1.0 - D[t]
            delta = R[t] + gamma * V[t + 1] * nonterm - V[t]
            last = delta + gamma * lamb * nonterm * last
            adv[t] = last
        ret = adv + V[:N]
        ep_EE = []
        for i in range(n_env):
            if env.alive[i]:
                tot = env.bits[i].sum(); ep_EE.append(tot / env.E[i])
        if lag:   # dual ascent on mean shortfall (dead/battery-overrun episodes count as full shortfall)
            shorts = [np.clip(1 - env.bits[i] / P['Rmin'], 0, None).sum() if env.alive[i] else float(K) for i in range(n_env)]
            ms = float(np.mean(shorts)) / K
            lam = float(np.clip(lam + eta * (ms - tol) * 10, 0.0, 600.0))
        curve.append(dict(lam=lam if lag else None, upd=upd, EE=float(np.mean(ep_EE)) if ep_EE else 0.0,
                          ret=float(R.sum(0).mean()), alive=float(env.alive.mean()),
                          minratio=float(np.mean([env.bits[i].min() / P['Rmin'] for i in range(n_env) if env.alive[i]])) if ep_EE else 0.0,
                          rmin_ok=float(np.mean([env.bits[i].min() >= P['Rmin'] for i in range(n_env) if env.alive[i]])) if ep_EE else 0.0))
        m = alive_mask.reshape(-1) > 0
        Ob = torch.as_tensor(O.reshape(-1, OBS)[m]); Ab = torch.as_tensor(A.reshape(-1, ACT)[m])
        LPb = torch.as_tensor(LP.reshape(-1)[m]); ADV = adv.reshape(-1)[m]; RET = torch.as_tensor(ret.reshape(-1)[m])
        ADV = torch.as_tensor((ADV - ADV.mean()) / (ADV.std() + 1e-8))
        nb = len(Ob)
        for ep in range(8):
            idx = torch.randperm(nb)
            for s in range(0, nb, 512):
                b = idx[s:s + 512]
                dist = net.dist(Ob[b]); lp = dist.log_prob(Ab[b]).sum(1)
                ratio = (lp - LPb[b]).exp()
                l1 = ratio * ADV[b]; l2 = torch.clamp(ratio, 0.8, 1.2) * ADV[b]
                lpi = -torch.min(l1, l2).mean()
                lv = 0.5 * ((net.v(Ob[b]).squeeze(1) - RET[b]) ** 2).mean() * 0.1
                ent = dist.entropy().sum(1).mean()
                loss = lpi + lv - 0.001 * ent
                opt.zero_grad(); loss.backward()
                nn.utils.clip_grad_norm_(net.parameters(), 0.5); opt.step()
        if upd % 20 == 0 and log:
            print('upd %d EE %.0f ret %.2f alive %.2f rminok %.2f minratio %.2f t=%.0fs' % (upd, curve[-1]['EE'], curve[-1]['ret'], curve[-1]['alive'], curve[-1]['rmin_ok'], curve[-1]['minratio'], time.time() - t0), file=log, flush=True)
    return net, curve


if __name__ == '__main__':
    nu = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    net, curve = train(nu, seed=seed, log=sys.stdout)
    import os; os.makedirs('out', exist_ok=True)
    torch.save(net.state_dict(), 'out/m2_net_s%d.pt' % seed)
    json.dump(curve, open('out/m2_curve_s%d.json' % seed, 'w'))
    u = md.make_users(0)
    q, rho, pw, m = evaluate_policy(net, u)
    print({k: v for k, v in m.items()})
