# Energy-efficient UAV-mounted IRS communication — simulation code

Code and saved results for the manuscript *"Energy-Efficient UAV-Mounted IRS Communication: Alternating
Optimisation, Deep Reinforcement Learning and Multi-UAV Scheduling Compared"*.
Every number, table and figure in the paper is produced by the scripts below with fixed random seeds.

## Requirements
Python ≥ 3.11 and `pip install -r requirements.txt` (NumPy, SciPy/HiGHS, CVXPY with Clarabel, PyTorch CPU,
matplotlib, python-docx, openpyxl). Runs on a 2-core CPU; no GPU needed.

## Files
| File | Purpose |
|---|---|
| `model.py` | Scenario, channel (Eq. 1–2), rotary-wing power (Eq. 3), energy (Eq. 4), metrics, IRS phase-quantisation check |
| `m1.py` | M1: closed-form IRS phases + time-share LP + Dinkelbach/SCA trajectory (CVXPY/Clarabel) |
| `m2.py`, `m2b.py`, `m2c.py`, `m2d.py` | M2: PPO environment/agent; BC warm start; penalty-PPO; **constrained (Lagrangian) PPO** |
| `gen_expert.py` | M1 demonstrations on training layouts (seeds 100–219) for behaviour cloning |
| `m3.py` | M3: multi-UAV mode-based scheduling LP (association + interference coordination), fairness weight `fw` |
| `run_compare.py` | Main comparison on test layouts 0–9 (Tables 3–4, Figs 2–5) |
| `run_scaling.py` | Fleet scaling U = 1–4, K = 8 (Table 5, Fig 6) |
| `robust.py` | Imperfect CSI and IRS reconfiguration overhead |
| `directlink.py` | Direct BS–user link sensitivity |
| `multistart.py` | M1 multi-start spread |
| `fairness.py` | EE–fairness trade-off of M3 |
| `make_figs.py`, `fig_arch.py`, `build_paper.py` | Figures, summary statistics and the manuscript |
| `out/` | Saved results (`*.pkl`, `*.json`) |

## Reproduce
```bash
python gen_expert.py 120            # M1 expert data for BC (~10 min)
python m2b.py 500 && python m2c.py 2500     # penalty-PPO agent (original M2)
for s in 0 1 2 3 4; do python m2d.py $s 4000; done   # constrained PPO, 5 seeds
python run_scaling.py 5
python run_compare.py
python robust.py 0,1,2,3,4 ; python directlink.py ; python multistart.py 2 ; python fairness.py
python make_figs.py && python fig_arch.py && python build_paper.py
```

## Archiving
Push this folder to a public GitHub repository and enable the Zenodo–GitHub integration to mint a DOI,
then add the DOI to the manuscript's Data-availability statement. Choose a licence (e.g. MIT) before release.
