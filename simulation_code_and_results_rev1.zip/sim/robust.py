"""Fix #3: imperfect CSI (lognormal gain-estimate error, dB) and IRS reconfiguration overhead (s per switch)."""
import sys, json, pickle, numpy as np, torch, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(1)
import model as md, m1, m2
from model import P, BS_POS

cmp_ = pickle.load(open('out/compare.pkl', 'rb'))
nets = {}
for tag, path in [('M2_old', 'out/m2_final2.pt')] + [('M2L_s%s' % a, 'out/m2L_s%s.pt' % a) for a in sys.argv[1].split(',')] if len(sys.argv) > 1 else [('M2_old', 'out/m2_final2.pt')]:
    n = m2.AC(); n.load_state_dict(torch.load(path)); n.eval(); nets[tag] = n
SIG = [0, 2, 4, 6, 8]; TAU = [0.0, 0.02, 0.05, 0.10]; DRAWS = 5
THR = 0.05


def overhead(rho, tau):
    nact = (rho > THR).sum(1)
    f = np.clip(1 - tau * nact / P['delta'], 0, 1)
    return rho * f[:, None]


def ev(q, u, rho, tau=0.0, Ptx=P['Pmax']):
    m = md.metrics_single(q, u, overhead(rho, tau), Ptx)
    return m['EE'], m['bits_k'].min() / P['Rmin'], bool(m['bits_k'].min() >= 0.995 * P['Rmin'])


if __name__ == '__main__':
    out = {'sigma': {}, 'tau': {}}
    for kind, grid in (('sigma', SIG), ('tau', TAU)):
        for g in grid:
            res = {k: [] for k in ['M1', 'tour'] + list(nets)}
            for r in cmp_:
                u = r['users']; s = r['seed']
                for d in range(DRAWS if kind == 'sigma' and g > 0 else 1):
                    rng = np.random.default_rng(1000 * s + d)
                    sig = g if kind == 'sigma' else 0.0; tau = g if kind == 'tau' else 0.0
                    for name, q in (('M1', r['q_M1']), ('tour', r['q_tour'])):
                        G = md.gain(q, BS_POS[0], u, P['H'])
                        Gest = G * 10 ** (sig * rng.standard_normal(G.shape) / 10)
                        rho = m1.schedule_lp(Gest, P['Pmax'])
                        res[name].append(ev(q, u, rho, tau))
                    for name, net in nets.items():
                        q, rho, pw, m = m2.evaluate_policy(net, u, seed=1000 * s + d, csi_sigma=sig)
                        res[name].append(ev(q, u, rho, tau, pw))
            out[kind][str(g)] = {k: dict(EE=float(np.mean([x[0] for x in v])), EEsd=float(np.std([x[0] for x in v], ddof=1)), minratio=float(np.mean([x[1] for x in v])), feas=float(np.mean([x[2] for x in v])), n=len(v)) for k, v in res.items()}
            print(kind, g, {k: (round(v['EE']), round(v['minratio'], 2), round(v['feas'], 2)) for k, v in out[kind][str(g)].items()}, flush=True)
    json.dump(out, open('out/robust.json', 'w'), indent=1)

