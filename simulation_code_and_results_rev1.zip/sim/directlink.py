"""Fix #4: add the direct BS-user link (3GPP UMa NLoS path loss minus extra blockage loss Lb) and re-evaluate."""
import json, pickle, numpy as np, warnings
warnings.filterwarnings('ignore')
import model as md, m1
from model import P, BS_POS
cmp_ = pickle.load(open('out/compare.pkl', 'rb'))
LB = [None, 30, 20, 10, 0]      # None = fully blocked (paper default)
fc = P['fc'] / 1e9


def gdirect(q, u, Lb):
    if Lb is None: return np.zeros((len(q), len(u)))
    d3 = np.sqrt(np.sum((q[:, None, :] - BS_POS[0]) ** 2, 2) * 0 + np.sum((q[:, None, :] * 0 + u[None, :, :] - BS_POS[0]) ** 2, 2) + P['Hb'] ** 2)
    pl = 13.54 + 39.08 * np.log10(d3) + 20 * np.log10(fc)
    return 10 ** (-(pl + Lb - P['gb_bs']) / 10)       # BS antenna gain included


def run(q, u, Lb, coherent=True):
    gi = md.gain(q, BS_POS[0], u, P['H'], coherent)
    gd = gdirect(q, u, Lb)
    G = (np.sqrt(gi) + np.sqrt(gd)) ** 2 if coherent else gi + gd      # random IRS phases add incoherently
    rho = m1.schedule_lp(G, P['Pmax'])
    m = md.metrics_single(q, u, rho, P['Pmax'], gscale=1.0) if False else None
    # evaluate with explicit gain
    snr = P['Pmax'] * G / P['sigma2']
    bits = (P['delta'] * rho * P['B'] * np.log2(1 + snr)).sum(0)
    E = md.prop_energy(q) + md.comm_energy(rho.sum(1), P['Pmax'])
    return bits.sum() / E, bits.min() >= 0.995 * P['Rmin']


out = {}
for Lb in LB:
    row = {}
    for name, key, coh in (('M1+IRS', 'q_M1', True), ('M1 traj, random phases', 'q_M1', False), ('Tour+IRS', 'q_tour', True), ('Tour, random phases', 'q_tour', False)):
        v = [run(r[key], r['users'], Lb, coh) for r in cmp_]
        row[name] = dict(EE=float(np.mean([x[0] for x in v])), sd=float(np.std([x[0] for x in v], ddof=1)), feas=int(sum(x[1] for x in v)))
    row['IRS_gain_pct'] = 100 * (row['M1+IRS']['EE'] / row['M1 traj, random phases']['EE'] - 1)
    out[str(Lb)] = row
    print(Lb, {k: (round(v['EE']), v['feas']) if isinstance(v, dict) else round(v, 1) for k, v in row.items()}, flush=True)
json.dump(out, open('out/directlink.json', 'w'), indent=1)
