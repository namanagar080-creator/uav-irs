"""System model for energy-aware UAV-mounted-IRS communication.
Shared by M1 (alternating optimisation), M2 (PPO) and M3 (multi-UAV scheduling).
All SI units unless stated.
"""
import numpy as np

# ---------------- scenario / physical parameters ----------------
P = dict(
    area=400.0,            # m, square side
    N=100, T=100.0,        # slots, mission duration (s)  -> delta = 1 s
    Vmax=20.0,             # m/s
    H=50.0,                # UAV(IRS) altitude (m); UAV i flies at H+10*i
    Hb=25.0,               # BS antenna height (m)
    fc=3.5e9, B=1e6, NF=7.0,
    Pmax=0.25,             # W BS transmit power
    xi_pa=0.4,             # PA efficiency
    M=64, bits=2,         # IRS elements, phase-shifter resolution
    Pel=0.01,              # W per IRS element (control circuit)
    gb_bs=15.0,            # dB BS antenna gain
    eta_nlos=0.01,         # NLoS excess (-20 dB) for IRS-user link
    a_los=9.61, b_los=0.16,  # Al-Hourani urban
    # rotary-wing (Zeng, Xu, Zhang 2019)
    P0=79.86, Pi=88.63, Utip=120.0, v0=4.03, d0=0.6, rho=1.225, s=0.05, A=0.503,
    Ebatt=1.08e6,          # J (0.3 kWh) for endurance figure
    Emission=15.0e3,       # J mission energy budget (battery-aware constraint of M2)
    Rmin=4.0e7,            # bits each user must receive over the mission (0.4 Mbps average)
    gam_th=1.0,            # linear SNR threshold for outage / coverage (0 dB)
    m_fade=4.0,            # Nakagami-m (power Gamma) shape for outage MC
)
P['delta'] = P['T'] / P['N']
P['kappa'] = 0.5 * P['d0'] * P['rho'] * P['s'] * P['A']
lam = 3e8 / P['fc']
P['beta0'] = (lam / (4 * np.pi)) ** 2          # free-space gain at 1 m
P['sigma2'] = 10 ** ((-174 + 10 * np.log10(P['B']) + P['NF'] - 30) / 10)
P['beta1'] = P['beta0'] * 10 ** (P['gb_bs'] / 10)   # BS->IRS (BS antenna gain)
P['beta2'] = P['beta0']                              # IRS->user
BS_POS = np.array([[0., 0.], [400., 0.], [0., 400.], [400., 400.]])
DEPOT = np.array([200., 200.])


def phase_quant_factor(bits, M=64, trials=200, seed=0):
    """Element-level check: UPA IRS, LoS BS->IRS and IRS->user steering vectors.
    Returns mean ratio |sum h1 h2 exp(j theta_q)|^2 / M^2 (1.0 for continuous)."""
    rng = np.random.default_rng(seed)
    side = int(np.sqrt(M))
    ix, iy = np.meshgrid(np.arange(side), np.arange(side))
    ix, iy = ix.ravel(), iy.ravel()
    out = []
    for _ in range(trials):
        ph1 = rng.uniform(0, 2 * np.pi, 2)
        ph2 = rng.uniform(0, 2 * np.pi, 2)
        a1 = np.exp(1j * np.pi * (ix * np.sin(ph1[0]) * np.cos(ph1[1]) + iy * np.sin(ph1[0]) * np.sin(ph1[1])))
        a2 = np.exp(1j * np.pi * (ix * np.sin(ph2[0]) * np.cos(ph2[1]) + iy * np.sin(ph2[0]) * np.sin(ph2[1])))
        th = -np.angle(a1 * a2)
        if bits is not None and bits < 16:
            step = 2 * np.pi / 2 ** bits
            th = np.round(th / step) * step
        out.append(np.abs(np.sum(a1 * a2 * np.exp(1j * th))) ** 2 / M ** 2)
    return float(np.mean(out))


def random_phase_factor(M=64, trials=2000, seed=1):
    """E|sum exp(j phi_m)|^2 / M^2 for random (uncontrolled) phases = 1/M."""
    rng = np.random.default_rng(seed)
    v = np.abs(np.exp(1j * rng.uniform(0, 2 * np.pi, (trials, M))).sum(1)) ** 2 / M ** 2
    return float(v.mean())


ZETA = phase_quant_factor(P['bits'])          # coherent gain factor from b-bit shifters
ZETA_RAND = random_phase_factor()


def Ccoef(coherent=True):
    base = P['M'] ** 2 * P['beta1'] * P['beta2']
    return base * (ZETA if coherent else ZETA_RAND)


def p_los(r, H):
    th = np.degrees(np.arctan2(H, r))
    return 1.0 / (1.0 + P['a_los'] * np.exp(-P['b_los'] * (th - P['a_los'])))


def eta_iu(r, H):
    pl = p_los(r, H)
    return pl + (1 - pl) * P['eta_nlos']


def sq_dists(q, bs, users, H):
    """q:(N,2), bs:(2,), users:(K,2) -> d1sq (N,), d2sq (N,K), r_h (N,K) horizontal IRS-user distance."""
    d1 = np.sum((q - bs) ** 2, 1) + (H - P['Hb']) ** 2
    dd = q[:, None, :] - users[None, :, :]
    rh2 = np.sum(dd ** 2, 2)
    d2 = rh2 + H ** 2
    return d1, d2, np.sqrt(rh2)


def gain(q, bs, users, H, coherent=True):
    d1, d2, rh = sq_dists(q, bs, users, H)
    return Ccoef(coherent) * eta_iu(rh, H) / (d1[:, None] * d2)


def prop_power(V):
    V = np.asarray(V, float)
    t1 = P['P0'] * (1 + 3 * V ** 2 / P['Utip'] ** 2)
    t2 = P['Pi'] * np.sqrt(np.sqrt(1 + V ** 4 / (4 * P['v0'] ** 4)) - V ** 2 / (2 * P['v0'] ** 2))
    t3 = P['kappa'] * V ** 3
    return t1 + t2 + t3


def step_speeds(q, start=None):
    start = DEPOT if start is None else start
    prev = np.vstack([start, q[:-1]])
    return np.linalg.norm(q - prev, axis=1) / P['delta']


def prop_energy(q, start=None):
    return float(np.sum(prop_power(step_speeds(q, start)) * P['delta']))


def comm_energy(rho_sum, Ptx):
    """BS transmit (incl. PA efficiency) + IRS control circuit, joules."""
    return float(np.sum(P['delta'] * (rho_sum * Ptx / P['xi_pa'] + P['M'] * P['Pel'])))


def jain(x):
    x = np.asarray(x, float)
    return float(x.sum() ** 2 / (len(x) * np.sum(x ** 2) + 1e-30))


def outage_mc(snr, w, rng, nsamp=300):
    """Time-share-weighted outage probability under Gamma(m) power fading.
    snr, w: arrays of same shape (mean SNR, scheduling weight)."""
    m = P['m_fade']
    snr = np.asarray(snr).ravel(); w = np.asarray(w).ravel()
    keep = w > 1e-6
    if keep.sum() == 0:
        return 1.0
    snr, w = snr[keep], w[keep]
    X = rng.gamma(m, 1.0 / m, size=(nsamp, len(snr)))
    out = (snr[None, :] * X < P['gam_th']).astype(float)
    return float((out.mean(0) * w).sum() / w.sum())


def metrics_single(q, users, rho, Ptx, bs=None, H=None, rng=None, start=None, gscale=1.0):
    """Evaluate a single-UAV mission.  rho:(N,K) time shares, Ptx:(N,) or scalar W."""
    bs = BS_POS[0] if bs is None else bs
    H = P['H'] if H is None else H
    rng = np.random.default_rng(0) if rng is None else rng
    N, K = rho.shape
    Ptx = np.broadcast_to(np.asarray(Ptx, float), (N,))
    G = gain(q, bs, users, H) * gscale
    snr = Ptx[:, None] * G / P['sigma2']
    rate = P['B'] * np.log2(1 + snr)
    bits_k = (P['delta'] * rho * rate).sum(0)
    Ep = prop_energy(q, start)
    Ec = comm_energy(rho.sum(1), Ptx)
    Et = Ep + Ec
    tot = bits_k.sum()
    d = np.linalg.norm(np.diff(np.vstack([DEPOT if start is None else start, q]), axis=0), axis=1)
    cov = float(np.mean(snr >= P['gam_th']))
    return dict(EE=tot / Et, sum_rate=tot / P['T'], min_rate=bits_k.min() / P['T'],
                bits_k=bits_k, E_prop=Ep, E_comm=Ec, E_tot=Et,
                endurance_h=P['Ebatt'] / (Et / P['T']) / 3600,
                traj_len=float(d.sum()), coverage=cov,
                outage=outage_mc(snr, rho, rng), jain=jain(bits_k),
                rmin_ok=bool(bits_k.min() >= P['Rmin'] * 0.995))


# ---------------- scenario generation ----------------
def make_users(seed, K=6, margin=60.0, min_sep=60.0):
    rng = np.random.default_rng(1000 + seed)
    pts = []
    while len(pts) < K:
        c = rng.uniform(margin, P['area'] - margin, 2)
        if all(np.linalg.norm(c - p) > min_sep for p in pts):
            pts.append(c)
    return np.array(pts)


def init_tour(users, N=None, start=None):
    """Nearest-neighbour tour depot -> users -> depot at constant speed (arc-length param)."""
    N = P['N'] if N is None else N
    start = DEPOT if start is None else start
    rest = list(range(len(users)))
    order, cur = [], start
    while rest:
        j = min(rest, key=lambda i: np.linalg.norm(users[i] - cur))
        order.append(j); rest.remove(j); cur = users[j]
    wp = np.vstack([start] + [users[j] for j in order] + [start])
    seg = np.linalg.norm(np.diff(wp, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    tt = np.linspace(0, s[-1], N + 1)[1:]
    q = np.stack([np.interp(tt, s, wp[:, 0]), np.interp(tt, s, wp[:, 1])], 1)
    return q


if __name__ == '__main__':
    print('zeta(2bit)=%.3f zeta_rand=%.4f beta0=%.3e sigma2=%.3e' % (ZETA, ZETA_RAND, P['beta0'], P['sigma2']))
    print('hover power', prop_power(0), 'P(10)', prop_power(10), 'P(20)', prop_power(20))
    Vs = np.linspace(0, 20, 201); pw = prop_power(Vs)
    print('min-power speed', Vs[pw.argmin()], pw.min())
    u = make_users(0)
    q = init_tour(u)
    rho = np.zeros((P['N'], len(u)))
    G = gain(q, BS_POS[0], u, P['H'])
    rho[np.arange(P['N']), G.argmax(1)] = 1
    m = metrics_single(q, u, rho, P['Pmax'])
    print({k: v for k, v in m.items()})
