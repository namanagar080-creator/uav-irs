"""Generate M1 expert trajectories on TRAINING layouts (seeds 100+, disjoint from test seeds 0-9)."""
import sys, numpy as np, pickle, warnings
warnings.filterwarnings('ignore')
import model as md, m1, m2
from multiprocessing import Pool


def job(seed):
    rng = np.random.default_rng(seed)
    u = m2.sample_users(rng)
    q, rho, m = m1.run_m1(u, max_iter=10)
    return dict(users=u, q=q, rho=rho, EE=m['EE'])


if __name__ == '__main__':
    n = int(sys.argv[1])
    with Pool(2) as p:
        res = p.map(job, range(100, 100 + n))
    pickle.dump(res, open('out/expert.pkl', 'wb'))
    print('done', n, np.mean([r['EE'] for r in res]))
