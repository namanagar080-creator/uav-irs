"""M1 - joint alternating optimisation of UAV trajectory, IRS phases (closed form) and
time-division scheduling, maximising energy efficiency (bits/J) via Dinkelbach + SCA.

Alternation (one outer iteration):
  (a) IRS phases : closed-form conjugate alignment per (slot,user); b-bit projection (factor ZETA).
  (b) scheduling : LP over time shares rho[n,k]  (max bits s.t. per-user Rmin).
  (c) trajectory : SCA convex program (CVXPY/Clarabel) maximising  bits_lb - lambda * E_prop_ub,
                   lambda = current EE (Dinkelbach); trust-region + backtracking acceptance.
"""
import numpy as np, cvxpy as cp
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
import model as md
from model import P, BS_POS, DEPOT


def schedule_lp(G, Ptx, rmin_bits=None, fixed_other=None):
    """max sum bits s.t. rho>=0, sum_k rho<=1, bits_k (+other) >= Rmin (soft with slack)."""
    N, K = G.shape
    rate = P['delta'] * P['B'] * np.log2(1 + Ptx * G / P['sigma2'])   # bits per full slot
    rmin = P['Rmin'] if rmin_bits is None else rmin_bits
    other = np.zeros(K) if fixed_other is None else fixed_other
    # vars: rho (N*K), slack (K). minimise -sum(rate*rho) + BIG*sum(slack)
    nv = N * K + K
    sc = 1e6                                   # work in Mbit for numerical conditioning
    rate_s = rate / sc; rmin_s = rmin / sc; other_s = other / sc
    c = np.concatenate([-rate_s.ravel(), np.full(K, 1e3 * max(rate_s.max(), 1e-3))])
    rows = np.repeat(np.arange(N), K); cols = np.arange(N * K)
    A1 = coo_matrix((np.ones(N * K), (rows, cols)), shape=(N, nv))
    r2 = np.tile(np.arange(K), N)
    A2 = coo_matrix((np.concatenate([-rate_s.ravel(), -np.ones(K)]),
                     (np.concatenate([r2, np.arange(K)]), np.concatenate([cols, N * K + np.arange(K)]))), shape=(K, nv))
    from scipy.sparse import vstack
    A = vstack([A1, A2]).tocsr()
    b = np.concatenate([np.ones(N), -(rmin_s - other_s)])
    res = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)] * nv, method='highs')
    if res.x is None:
        rho = np.zeros((N, K)); rho[np.arange(N), G.argmax(1)] = 1.0
        return rho
    rho = res.x[:N * K].reshape(N, K)
    return np.clip(rho, 0, 1)


def sca_step(q0, users, rho, Ptx, lam, bs, H, rmin_bits, other_bits, y0, trust):
    """One convex SCA subproblem. returns new q, y."""
    rho = np.where(rho < 1e-5, 0.0, rho)
    N, K = rho.shape
    dl = P['delta']
    SC = 1.0
    d1, d2, rh = md.sq_dists(q0, bs, users, H)
    eta = md.eta_iu(rh, H)
    a = Ptx * md.Ccoef(True) * eta / P['sigma2'] / (d1[:, None] * d2) * (d1[:, None] * d2)  # placeholder
    # a_nk such that SNR = a_nk/(x*y): a = Ptx*Ccoef*eta/sigma2
    a = Ptx * md.Ccoef(True) * eta / P['sigma2']
    u0 = np.log(d1)[:, None] + np.log(d2)
    e = a * np.exp(-u0)
    f0 = np.log2(1 + e)
    f1 = -(e / (1 + e)) / np.log(2)              # d f / d u  (<0)
    q = cp.Variable((N, 2))
    y = cp.Variable(N, nonneg=True)
    slack = cp.Variable(K, nonneg=True)
    x_expr = cp.square(q[:, 0] - bs[0]) + cp.square(q[:, 1] - bs[1]) + (H - P['Hb']) ** 2
    bits = []
    for k in range(K):
        if rho[:, k].sum() == 0:
            bits.append(cp.Constant(0.0)); continue
        yk = cp.square(q[:, 0] - users[k, 0]) + cp.square(q[:, 1] - users[k, 1]) + H ** 2
        coef = (rho[:, k] * f1[:, k])                      # <=0
        lb = cp.multiply(rho[:, k], f0[:, k]) + cp.multiply(coef, cp.multiply(x_expr, 1.0 / d1) + cp.multiply(yk, 1.0 / d2[:, k]) - 2)
        bits.append(SC * dl * P['B'] * cp.sum(lb))
    bits = cp.hstack(bits)
    # propulsion energy upper bound
    prev = cp.vstack([DEPOT.reshape(1, 2), q[:-1, :]])
    dq = q - prev
    prev0 = np.vstack([DEPOT, q0[:-1]]); dq0 = q0 - prev0
    v2_lb = (2 * cp.sum(cp.multiply(dq, dq0), axis=1) - np.sum(dq0 ** 2, 1)) / dl ** 2
    v2 = cp.sum_squares  # unused
    v_sq = cp.hstack([cp.sum_squares(dq[i]) for i in range(N)]) / dl ** 2
    v3 = cp.hstack([cp.power(cp.norm(dq[i]), 3) for i in range(N)]) / dl ** 3
    cons = [q[N - 1] == DEPOT,
            cp.hstack([cp.norm(dq[i]) for i in range(N)]) <= P['Vmax'] * dl,
            cp.abs(q - q0) <= trust,
            q >= 0, q <= P['area']]
    # induced-power auxiliary: v_lb^2 + v0^2*(2 y0 y - y0^2) >= v0^2 / y^2
    v0 = P['v0']
    cons.append(v2_lb + v0 ** 2 * (2 * cp.multiply(y0, y) - y0 ** 2) >= v0 ** 2 * cp.power(y, -2))
    cons.append(y <= 1.0)
    act = np.array([rho[:, k].sum() > 0 for k in range(K)])
    other_arr = np.broadcast_to(np.asarray(other_bits, float), (K,))
    cons.append(bits[act] + other_arr[act] + slack[act] >= rmin_bits)
    cons.append(slack[~act] == 0)
    E = SC * dl * (P['P0'] * (1 + 3 * v_sq / P['Utip'] ** 2) + P['Pi'] * y + P['kappa'] * v3)
    obj = cp.Maximize(cp.sum(bits) - lam * cp.sum(E) - 1e3 * lam * cp.sum(slack))
    prob = cp.Problem(obj, cons)
    try:
        prob.solve(solver=cp.CLARABEL, max_iter=300)
    except Exception as ex:
        print('solver exc', ex)
        return None, None
    if q.value is None:
        print('status', prob.status)
        return None, None
    return np.array(q.value), np.array(y.value)


def y_of_v(v):
    return np.sqrt(np.sqrt(1 + v ** 4 / (4 * P['v0'] ** 4)) - v ** 2 / (2 * P['v0'] ** 2))


def run_m1(users, bs=None, H=None, q_init=None, max_iter=40, tol=1e-3, verbose=False, rng=None,
           fixed_rho=None, rmin_bits=None):
    bs = BS_POS[0] if bs is None else bs
    H = P['H'] if H is None else H
    q = md.init_tour(users) if q_init is None else q_init.copy()
    Ptx = P['Pmax']
    trust = 40.0
    hist = []

    def evaluate(qq):
        G = md.gain(qq, bs, users, H)
        rho = schedule_lp(G, Ptx, rmin_bits)
        m = md.metrics_single(qq, users, rho, Ptx, bs, H, rng)
        # penalise infeasible (rate shortfall) solutions in the acceptance metric
        short = max(0.0, (P['Rmin'] if rmin_bits is None else rmin_bits) - m['bits_k'].min())
        m['score'] = m['EE'] - 1e3 * short / (P['Rmin'] if rmin_bits is None else rmin_bits) * m['EE']
        return rho, m

    rho, m = evaluate(q)
    hist.append(m['EE'])
    stall = 0
    for it in range(max_iter):
        lam = m['EE']
        v = md.step_speeds(q)
        y0 = np.clip(y_of_v(v), 1e-3, 1.0)
        qn, yn = sca_step(q, users, rho, Ptx, lam, bs, H, P['Rmin'] if rmin_bits is None else rmin_bits,
                          0.0, y0, trust)
        if qn is None:
            trust *= 0.5
            if trust < 1: break
            continue
        accepted = False
        for s in (1.0, 0.5, 0.25):
            qc = q + s * (qn - q)
            rc, mc = evaluate(qc)
            if mc['score'] > m['score'] * (1 + 1e-9):
                accepted = True; break
        if not accepted:
            trust *= 0.5
            stall += 1
            if trust < 1 or stall >= 3: break
            continue
        gain_rel = (mc['score'] - m['score']) / abs(m['score'])
        q, rho, m = qc, rc, mc
        hist.append(m['EE'])
        if verbose: print(it, 'EE=%.1f len=%.0f Eprop=%.0f min=%.2e' % (m['EE'], m['traj_len'], m['E_prop'], m['bits_k'].min()))
        if gain_rel < tol:
            stall += 1
            if stall >= 2: break
        else:
            stall = 0
    m['hist'] = hist
    m['iters'] = len(hist) - 1
    return q, rho, m


if __name__ == '__main__':
    import time
    u = md.make_users(0)
    t = time.time()
    q, rho, m = run_m1(u, verbose=True)
    print('time', time.time() - t)
    print({k: v for k, v in m.items() if k != 'hist'})
