"""Constrained PPO (learned Lagrange multiplier) from a BC warm start. usage: m2d.py seed n_updates"""
import sys, json, pickle, numpy as np, torch, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(1)
import m2, m2b
seed = int(sys.argv[1]); nu = int(sys.argv[2])
experts = pickle.load(open('out/expert.pkl', 'rb'))
O, A, G, _ = m2b.expert_data(experts)
torch.manual_seed(seed)
net = m2.AC(); m2b.bc(net, O, A, G, seed=seed)
before = m2b.eval_set(net, range(10))
net, curve = m2.train(nu, n_env=16, seed=100 + seed, log=sys.stdout, net=net, std0=-1.6, std1=-2.0, lr=1e-4, lag=True)
after = m2b.eval_set(net, range(10))
print('seed %d  BC EE %.0f  Lag-PPO EE %.0f  rminok %d/10 batt %d/10 minrate %.3f' % (seed, np.mean([b['EE'] for b in before]), np.mean([b['EE'] for b in after]),
      sum(b['rmin_ok'] for b in after), sum(b['battery_ok'] for b in after), np.mean([b['min_rate'] for b in after]) / 1e6), flush=True)
torch.save(net.state_dict(), 'out/m2L_s%d.pt' % seed)
json.dump(dict(curve=curve, before=before, after=after), open('out/m2L_s%d.json' % seed, 'w'))
