"""Applies the second-level (minor) corrections to build_paper.py -> build_paper_rev.py."""
s = open('build_paper.py').read()

def rep(old, new, count=1):
    global s
    assert old in s, old[:80]
    s = s.replace(old, new, count)

# ---------------- new data
rep("sum_ratio = S['M3']['sum_rate'][0] / S['M1']['sum_rate'][0]\n", r'''sum_ratio = S['M3']['sum_rate'][0] / S['M1']['sum_rate'][0]
import pickle as _pk
M2L = [json.load(open('out/m2L_s%d.json' % k)) for k in range(5)]
l_ee = np.array([np.mean([a['EE'] for a in m['after']]) for m in M2L])
l_feas = int(sum(sum(a['rmin_ok'] for a in m['after']) for m in M2L))
l_batt = int(sum(sum(a['battery_ok'] for a in m['after']) for m in M2L))
l_min = np.array([np.mean([a['min_rate'] for a in m['after']]) for m in M2L])
l_minfrac = 100 * l_min.mean() / (P['Rmin'] / P['T'])
l_lamcap = sum(1 for m in M2L if m['curve'][-1]['lam'] >= 599)
# per-layout average across seeds, paired test vs M1
_cmp = _pk.load(open('out/compare.pkl', 'rb'))
_m1 = np.array([r['M1']['EE'] for r in _cmp])
lay = {k: np.array([np.mean([m['after'][i][k] for m in M2L]) for i in range(10)]) for k in ('EE', 'sum_rate', 'min_rate', 'outage')}
l_t, l_p = stats.ttest_rel(lay['EE'], _m1)
l_rel = 100 * (lay['EE'].mean() / _m1.mean() - 1)
RM = json.load(open('out/robust_margin.json')); RB = json.load(open('out/robust.json')); DL = json.load(open('out/directlink.json'))
MS = json.load(open('out/multistart.json')); FR = json.load(open('out/fairness.json'))
ms_best = sum(1 for _, o in MS if o[0][0] >= max(x[0] for x in o) - 1e-6)
ms_gap = np.array([100 * (1 - o[0][0] / max(x[0] for x in o)) for _, o in MS])
ms_spread = np.array([100 * (1 - min(x[0] for x in o) / max(x[0] for x in o)) for _, o in MS])
ms_runs = sum(len(o) for _, o in MS); ms_feas = sum(x[1] for _, o in MS for x in o)
lagk = [k for k in RB['sigma']['0'] if k.startswith('M2L')]
def rb(kind, g, key, met):
    d = RB[kind][str(g)]
    return np.mean([d[k][met] for k in lagk]) if key == 'M2L' else d[key][met]
sig_max = max(float(x) for x in RB['sigma'])
m1_over_lag = [rb('sigma', g, 'M1', 'EE') / rb('sigma', g, 'M2L', 'EE') for g in RB['sigma']]
''')

# ---------------- abstract (<= 250 words)
a0 = s.index("abstract = (")
a1 = s.index("B.p(__import__('docx_lib').runs(abstract")
s = s[:a0] + r'''abstract = (
    'Unmanned aerial vehicles (UAVs) carrying intelligent reflecting surfaces (IRSs) can extend coverage, but propulsion dominates their energy budget, so flight path and IRS configuration must be designed jointly. '
    'Optimisation-based, learning-based and multi-UAV designs are rarely compared under one energy model. '
    'We benchmark three approaches that maximise energy efficiency under per-user rate floors and a return-to-depot constraint: alternating optimisation of trajectory, IRS phases and scheduling (M1); proximal policy optimisation (PPO) with a battery budget, in penalty and Lagrangian-constrained forms (M2); and interference-aware scheduling of several UAV-IRS nodes (M3). '
    'On ten identical layouts of a synthetic 3.5 GHz scenario with a rotary-wing power model, M1 reached %s kbit/J, %.1f%% above a tour baseline (paired p %s), and met every rate floor; random IRS phases cut efficiency by %.0f%%. '
    'Neither PPO configuration became feasible: across five constrained-PPO seeds the rate floor was met in %d of 50 runs, so these agents characterise the PPO set-ups tested rather than a limit of learning. '
    'Two cooperating UAVs delivered %.2f times the sum rate of M1 at statistically indistinguishable efficiency, and joint scheduling met the floors where uncoordinated operation mostly failed. '
    'Under gain-estimation errors up to %.0f dB M1 kept the highest efficiency, but no method met every floor without a planning margin. '
    'The IRS benefit depends on blockage: with an unblocked direct link it added only %.0f%%. '
    'Structured optimisation is therefore the stronger baseline for this known, decomposable model.'
) % (f('M1', 'EE', 1, 1e3), S['M1_vs_tour_pct'], pv(S['tour']['p_vs_M1']),
     100 * (1 - S['M1_randphase']['EE'][0] / S['M1']['EE'][0]), l_feas, sum_ratio, sig_max, DL['0']['IRS_gain_pct'])
print('abstract words:', len(abstract.split()))
''' + s[a1:]

# ---------------- contributions
rep("B.bullet('A battery-constrained proximal policy optimisation agent (M2) that controls velocity, transmit power and the IRS user-share as one sequential decision problem, together with a documented account of why it did not satisfy the per-user rate floors.')",
    "B.bullet('A battery-constrained proximal policy optimisation agent (M2) that controls velocity, transmit power and the IRS user-share as one sequential decision problem, in a penalty form and a Lagrangian-constrained form with a learned multiplier, evaluated over five training seeds.')")
rep("showing that M1 improves EE by %.1f%% over a tour baseline and that the learning-based agent does not match it.' % S['M1_vs_tour_pct'])",
    "showing that M1 improves EE by %.1f%% over a tour baseline and that neither PPO configuration tested matches it.' % S['M1_vs_tour_pct'])\nB.bullet('Sensitivity analyses that bound the claims: imperfect channel knowledge, IRS reconfiguration overhead, a restored direct BS-user link, an M1 multi-start spread as a proxy for the optimality gap, and the energy-efficiency versus fairness trade-off of M3.')")

# ---------------- 2.4 caveat sentence (authors' note, not reader-facing)
rep(" The table entries are condensed from titles and abstract-level information and should be checked against the full texts before submission.')", "')")

# ---------------- 3.1 direct link
rep("The direct BS-user link is assumed blocked, so every user is served through the IRS.",
    "In the baseline model the direct BS-user link is assumed blocked (for example by buildings), so every user is served through the IRS; Section 4.5 restores it.")

# ---------------- M2 method: Lagrangian form
rep("Training from random initialisation did not satisfy the rate floors (not shown), so the final agent is warm-started by behaviour cloning on 120 M1 solutions from training layouts and then fine-tuned with PPO.')",
    r"""Training from random initialisation did not satisfy the rate floors (not shown), so both M2 variants are warm-started by behaviour cloning on 120 M1 solutions from training layouts and then fine-tuned with PPO. In the constrained (Lagrangian) variant the progress bonus and terminal penalty are replaced by a multiplier ν on the total demand shortfall,')
B.equation(r'r_{n}=10^{-6}\Big(\sum_{k}b_{n,k}-\lambda_{0}e_{n}\Big)+\nu\sum_{k}\frac{\Delta\min(B_{k},R_{\min})}{R_{\min}},\qquad \nu\leftarrow\Big[\nu+\eta\big(\bar{s}-\epsilon\big)\Big]_{0}^{\nu_{\max}}', 8)
B.para('which is the dense form of −ν Σ~k~ (1 − B~k~/R~min~)^+^. After every PPO update ν is raised by dual ascent on the mean normalised shortfall s̄ of the batch (episodes that overrun the battery count as full shortfall), with η = 30, tolerance ε = 0.005, ν~0~ = 20 and ν~max~ = 600. This variant was trained with five seeds (0–4) for 4,000 updates each.')""")
rep("so the SINR of UAV i serving user k~i~ is')\nB.equation(r'\\gamma_{n,i}", "so the SINR of UAV i serving user k~i~ is')\nB.equation(r'\\gamma_{n,i}")
rep("\\,g^{(j)}_{n,k_{i}}}', 8)", "\\,g^{(j)}_{n,k_{i}}}', 9)")
rep("together. The trajectory of each UAV", "together. A fairness weight w~f~ ≥ 0 optionally adds w~f~K·min~k~ B~k~ to the objective (w~f~ = 0 is the default, pure EE). The trajectory of each UAV")

# ---------------- 3.4 robustness set-up
rep("A run counts as feasible if the minimum user receives at least 99.5% of R~min~.')",
    """A run counts as feasible if the minimum user receives at least 99.5% of R~min~.')
B.para('Four sensitivity analyses use the same ten layouts. (a) Imperfect CSI: the scheduler (M1 and tour) and the M2 policy see per-slot, per-user gain estimates with independent log-normal error of standard deviation σ ∈ {0, 2, 4, 6, 8} dB, while delivered bits use the true gains (five error draws per layout). (b) IRS reconfiguration overhead: every user with a time-share above 0.05 in a slot costs τ ∈ {0, 20, 50, 100} ms of airtime. (c) Direct link: a BS-user path with 3GPP urban-macro NLoS path loss 13.54 + 39.08 log~10~d + 20 log~10~f~c~ dB, the BS antenna gain, and an extra blockage loss L~b~ ∈ {∞, 30, 20, 10, 0} dB, combined coherently with the IRS path; trajectories are those optimised for the blocked case and only scheduling is re-solved. (d) Optimality: M1 is restarted from five random-order tours per layout in addition to the nominal start.')""")

# ---------------- Table 3: add constrained-PPO row
rep("         row('M2', 'M2 BC + PPO'), row('M3', 'M3 multi-UAV (U = 2)')]",
    "         row('M2', 'M2 penalty PPO (1 seed)'),\n         ['M2 constrained PPO (5 seeds)', '%.1f ± %.1f' % (lay['EE'].mean() / 1e3, lay['EE'].std(ddof=1) / 1e3), '%.2f ± %.2f' % (lay['sum_rate'].mean() / 1e6, lay['sum_rate'].std(ddof=1) / 1e6), '%.3f ± %.3f' % (lay['min_rate'].mean() / 1e6, lay['min_rate'].std(ddof=1) / 1e6), '%.3f ± %.3f' % (lay['outage'].mean(), lay['outage'].std(ddof=1)), '%d/50' % l_feas, pv(l_p)],\n         row('M3', 'M3 multi-UAV (U = 2)')]")
rep("Values are mean ± standard deviation over n = 10 runs; p-values are paired t-tests of EE against M1. Best feasible result in bold.')",
    "Values are mean ± standard deviation over n = 10 layouts (constrained PPO: per-layout mean over five seeds); p-values are paired t-tests of EE against M1. Best feasible result in bold.')")
rep("bold_rows=(2,))\nB.figure('figs/fig2_trajectories.png'", "bold_rows=(2,))\nB.figure('figs/fig2_trajectories.png'")
rep("Its trajectory (Figure 2) is smooth but loops wastefully.", "Its trajectory (Figure 2) is smooth but loops wastefully. The constrained variant is reported in Section 4.4.")

# ---------------- 4.2: rounding, explicit values
rep("so the default loses %.1f%% against ideal phases;", "so the default loses %.1f%% against ideal phases (computed from the unrounded means, %.2f and %.2f kbit/J);")
rep("'%.1f' % (ph['M1_bits_None'][0] / 1e3), loss2, '%.1f' % (ph['M1_bits_1'][0] / 1e3)))",
    "'%.1f' % (ph['M1_bits_None'][0] / 1e3), loss2, ph['M1_bits_2'][0] / 1e3, ph['M1_bits_None'][0] / 1e3, '%.1f' % (ph['M1_bits_1'][0] / 1e3)))")

# ---------------- 4.3 fairness, 4.4 constrained PPO, 4.5 robustness  (inserted before Discussion)
rep("# ------------------------------------------------------------ 5 Discussion", r'''B.para('The low Jain index at U ≥ 2 is a consequence of the objective rather than of coordination. Table 6 re-solves the M3 schedule on the same trajectories with the fairness weight w~f~. At U = 2, raising w~f~ from 0 to 100 lifts Jain\'s index from %.2f to %.2f and the minimum user rate from %.2f to %.2f Mbps, at a cost of %.0f%% in EE (%.1f to %.1f kbit/J); intermediate weights trace the trade-off, and w~f~ = 0.25 keeps EE within %.0f%% while raising the minimum rate to %.2f Mbps. Every setting remained feasible.' % (
    FR['2']['0.0']['jain'][0], FR['2']['100.0']['jain'][0], FR['2']['0.0']['min_rate'][0] / 1e6, FR['2']['100.0']['min_rate'][0] / 1e6,
    100 * (1 - FR['2']['100.0']['EE'][0] / FR['2']['0.0']['EE'][0]), FR['2']['0.0']['EE'][0] / 1e3, FR['2']['100.0']['EE'][0] / 1e3,
    100 * (1 - FR['2']['0.25']['EE'][0] / FR['2']['0.0']['EE'][0]), FR['2']['0.25']['min_rate'][0] / 1e6))
B.caption_above('Table 6.', 'Energy-efficiency versus fairness trade-off of M3 (K = 8, same trajectories as Table 5, mean over n = 5 layouts). w~f~: fairness weight.')
rows6 = []
for U in ('2', '3', '4'):
    for fw in ('0.0', '0.25', '1.0', '4.0', '100.0'):
        d = FR[U][fw]
        rows6.append([U if fw == '0.0' else '', fw.rstrip('0').rstrip('.') if fw != '0.0' else '0 (default)', '%.1f ± %.1f' % (d['EE'][0] / 1e3, d['EE'][1] / 1e3), '%.2f ± %.2f' % tuple(d['jain']), '%.3f' % (d['min_rate'][0] / 1e6), '%.2f' % (d['sum_rate'][0] / 1e6), '%d/5' % d['feas']])
B.table(['U', 'w~f~', 'EE (kbit/J)', 'Jain index', 'Min rate (Mbps)', 'Sum rate (Mbps)', 'Floor met'], rows6, [0.6, 1.3, 1.6, 1.5, 1.4, 1.4, 1.0], align=['center'] * 7, size=18)

B.h2('4.4 Constrained PPO over five seeds')
B.para('Table 7 reports the Lagrangian-constrained M2 for five training seeds. The multiplier rose quickly and reached its cap in %d of five runs, which pushed the agents towards serving every user: the least-served user\\'s rate rose to %.3f Mbps on average (%.0f%% of the floor), against %.3f Mbps for the penalty agent. Feasibility was still reached in only %d of 50 test runs, all runs stayed within the battery budget (%d of 50), and EE fell to %.1f ± %.1f kbit/J across seeds, %.1f%% below M1 (paired p %s on per-layout means). The constrained agent therefore traded efficiency for demand coverage without closing the gap. We read this as a property of the PPO set-ups tested here (network size, 120 demonstrations, 4,000 updates, one shared multiplier), not as evidence that constrained reinforcement learning cannot solve the problem.' % (
    l_lamcap, l_min.mean() / 1e6, l_minfrac, S['M2']['min_rate'][0] / 1e6, l_feas, l_batt, l_ee.mean() / 1e3, l_ee.std(ddof=1) / 1e3, abs(l_rel), pv(l_p)))
B.caption_above('Table 7.', 'Constrained (Lagrangian) PPO per training seed, evaluated on the ten test layouts. EE and minimum rate are means over the layouts.')
rows7 = []
for k, m in enumerate(M2L):
    a = m['after']
    rows7.append([str(k), '%.1f' % (np.mean([b['EE'] for b in a]) / 1e3), '%.3f' % (np.mean([b['min_rate'] for b in a]) / 1e6), '%d/10' % sum(b['rmin_ok'] for b in a), '%d/10' % sum(b['battery_ok'] for b in a), '%.0f' % m['curve'][-1]['lam']])
rows7.append(['Mean ± SD', '%.1f ± %.1f' % (l_ee.mean() / 1e3, l_ee.std(ddof=1) / 1e3), '%.3f ± %.3f' % (l_min.mean() / 1e6, l_min.std(ddof=1) / 1e6), '%d/50' % l_feas, '%d/50' % l_batt, '—'])
B.table(['Seed', 'EE (kbit/J)', 'Min user rate (Mbps)', 'Rate floor met', 'Battery respected', 'Final ν'], rows7, [1.2, 1.4, 1.8, 1.5, 1.6, 1.1], align=['center'] * 6, bold_rows=(5,))

B.h2('4.5 Robustness and sensitivity')
B.para('Figure 7 (left, centre) adds gain-estimation error. M1\\'s EE moved from %.1f to %.1f kbit/J between σ = 0 and %.0f dB, but its feasibility fell from %.0f%% of runs at σ = 0 to %.0f%% at %.0f dB (already 0%% at 2 dB), because the time-share LP is planned on wrong gains and the weakest user is the first to miss its floor; the tour baseline behaved the same way. The PPO agents, whose feasibility was already near zero, did not overtake M1 at any error level: M1\\'s EE stayed %.0f–%.0f%% above the constrained agents. IRS reconfiguration overhead scaled delivered bits almost linearly: at τ = 100 ms per switch M1 lost %.0f%% of its EE and met the floor in %.0f%% of layouts, against %.0f%% at τ = 0.' % (
    rb('sigma', 0, 'M1', 'EE') / 1e3, rb('sigma', sig_max if sig_max != int(sig_max) else int(sig_max), 'M1', 'EE') / 1e3, sig_max, 100 * rb('sigma', 0, 'M1', 'feas'), 100 * rb('sigma', int(sig_max), 'M1', 'feas'), sig_max,
    100 * (min(m1_over_lag) - 1), 100 * (max(m1_over_lag) - 1),
    100 * (1 - rb('tau', 0.1, 'M1', 'EE') / rb('tau', 0.0, 'M1', 'EE')), 100 * rb('tau', 0.1, 'M1', 'feas'), 100 * rb('tau', 0.0, 'M1', 'feas')))
B.para('M1\'s loss of feasibility under small errors is a margin effect: its schedule meets the floor exactly, so at σ = 2 dB the least-served user still received %.0f%% of its demand on average, and at τ = 20 ms %.0f%%. Planning the time-shares for a floor 10%% above R~min~ on the same trajectory cost %.0f%% of EE at σ = 0 and restored feasibility in %.0f%% of runs at τ = 50 ms and %.0f%% at σ = 2 dB, but in none at σ ≥ 4 dB. Larger margins were not attainable on trajectories optimised for the nominal floor (25%%: %.0f%% feasible even without error), so robust operation requires the margin to be built into the trajectory design.' % (
    100 * rb('sigma', 2, 'M1', 'minratio'), 100 * rb('tau', 0.02, 'M1', 'minratio'), 100 * (1 - RM['0.1']['sigma_0']['EE'] / rb('sigma', 0, 'M1', 'EE')),
    100 * RM['0.1']['tau_0.05']['feas'], 100 * RM['0.1']['sigma_2']['feas'], 100 * RM['0.25']['sigma_0']['feas']))
B.para('The direct link changes the picture substantially (Table 8 and Figure 7, right). With full blockage, phase control raises EE by %.0f%% over random phases on the same path; with 20 dB of extra blockage the gain is %.0f%%, with 10 dB %.0f%%, and with an unblocked urban-macro NLoS direct path only %.1f%%, while the absolute EE more than doubles because the direct path carries most of the energy. M1\\'s advantage over the tour shrinks accordingly, from %.1f%% to %.1f%%, though these trajectories were optimised for the blocked case. The IRS contributions reported in Sections 4.1–4.3 therefore hold for strongly blocked direct paths (roughly 20 dB or more of extra loss in this link budget) and should not be read as general.' % (
    DL['None']['IRS_gain_pct'], DL['20']['IRS_gain_pct'], DL['10']['IRS_gain_pct'], DL['0']['IRS_gain_pct'],
    100 * (DL['None']['M1+IRS']['EE'] / DL['None']['Tour+IRS']['EE'] - 1), 100 * (DL['0']['M1+IRS']['EE'] / DL['0']['Tour+IRS']['EE'] - 1)))
B.caption_above('Table 8.', 'Effect of restoring the direct BS-user link (mean over n = 10 layouts; scheduling re-solved, trajectories from the blocked case). L~b~: extra blockage loss on the direct path.')
rows8 = []
for lb in ('None', '30', '20', '10', '0'):
    d = DL[lb]
    rows8.append(['∞ (blocked)' if lb == 'None' else lb, '%.1f ± %.1f' % (d['M1+IRS']['EE'] / 1e3, d['M1+IRS']['sd'] / 1e3), '%.1f ± %.1f' % (d['M1 traj, random phases']['EE'] / 1e3, d['M1 traj, random phases']['sd'] / 1e3), '%.1f' % (d['Tour+IRS']['EE'] / 1e3), '%+.1f%%' % d['IRS_gain_pct'], '%d/10' % d['M1+IRS']['feas'], '%d/10' % d['M1 traj, random phases']['feas']])
B.table(['L~b~ (dB)', 'M1 + IRS (kbit/J)', 'Same path, random phases (kbit/J)', 'Tour + IRS (kbit/J)', 'IRS gain', 'Floor met (IRS)', 'Floor met (random)'], rows8, [1.3, 1.5, 1.9, 1.4, 1.1, 1.1, 1.2], align=['center'] * 7, size=18)
B.figure('figs/fig7_robust.png', 16.0, 'Figure 7.', 'Sensitivity analyses on the ten layouts. Left: energy efficiency (kbit/J) and centre: percentage of runs meeting the rate floor, against the standard deviation σ (dB) of the gain-estimation error seen by the scheduler or policy (M1, tour, penalty PPO, and the mean of five constrained-PPO seeds). Right: energy efficiency against the extra blockage loss of a restored direct BS-user link, for M1 with controlled and random IRS phases.')
B.para('Finally, as a practical proxy for the optimality gap of the non-convex problem, M1 was restarted from five random-order tours per layout (%d runs, all feasible: %d of %d). The nominal nearest-neighbour start gave the best of the six solutions in %d of ten layouts and was at most %.1f%% below the best in the others (mean %.2f%%), whereas the spread between the best and worst start averaged %.1f%% (up to %.1f%%). M1 is thus sensitive to initialisation, and the reported M1 figures are at most about %.1f%% below the best solution found; this is not a certificate of global optimality.' % (
    ms_runs, ms_feas, ms_runs, ms_best, ms_gap.max(), ms_gap.mean(), ms_spread.mean(), ms_spread.max(), ms_gap.max()))

# ------------------------------------------------------------ 5 Discussion''')

# ---------------- Discussion paragraphs
rep("We did not test model mismatch, where the ranking could reverse, and we make no claim that M2 is intrinsically inferior: its failure to meet the rate floors points to the difficulty of constraint handling with a sparse terminal penalty and 120 demonstrations.')",
    "Imperfect CSI was expected to be where learning could overtake M1; in our tests it did not, but the errors were applied to a model whose structure M1 still knows, and larger model mismatch (unknown blockage maps, mobility, learned channel maps) remains untested. A constrained formulation with a learned multiplier improved demand coverage but did not reach feasibility, so the comparison measures these PPO configurations, not a limit of learning.')")
rep("Third, fleet size should follow demand: in our scenario one UAV sufficed for the rate floors, and additional UAVs raised capacity and coverage at the price of lower EE once the floors were met; when interference is possible, joint scheduling is what keeps the floors satisfied.'",
    "Third, fleet size should follow demand: in our scenario one UAV sufficed for the rate floors, and additional UAVs raised capacity and coverage at the price of lower EE once the floors were met; when interference is possible, joint scheduling is what keeps the floors satisfied, and a fairness weight trades EE for a more even allocation. Fourth, an IRS is worth deploying where the direct path is heavily blocked; with a usable direct path its EE contribution is small.'")
a0 = s.index("B.para('Limitations should be read alongside the results.")
a1 = s.index("\n", a0)
s = s[:a0] + "B.para('Limitations should be read alongside the results. (i) The channel is a synthetic large-scale model with a LoS-probability term and no measured data; small-scale fading enters only the outage estimate. (ii) The direct-link, CSI and margin analyses re-solve scheduling on fixed trajectories rather than re-optimising the paths, which is conservative for M1. (iii) There are ten layouts for single-UAV comparisons and five for scaling; several scaling comparisons are underpowered, and the uncoordinated ablation isolates scheduling only. (iv) M2 covers two reward formulations and five seeds of the constrained one, but a single network size and demonstration budget. (v) The multi-start spread bounds sensitivity to initialisation but does not certify global optimality, and M3 was not multi-started. (vi) Collision avoidance is replaced by altitude separation. (vii) EE is propulsion-dominated by construction; a larger IRS or a multi-antenna BS would shift this balance.')" + s[a1:]

# ---------------- Conclusion
a0 = s.index("B.para('This study compared alternating optimisation (M1)")
a1 = s.index("# ------------------------------------------------------------ declarations")
s = s[:a0] + r'''B.para('This study compared alternating optimisation (M1), penalty and Lagrangian-constrained PPO agents (M2) and cooperative multi-UAV scheduling (M3) for energy-efficient UAV-mounted IRS communication on identical synthetic scenarios. M1 reached %s kbit/J, %.1f%% above a tour baseline, while meeting all rate floors, and kept the highest efficiency under gain-estimation errors up to %.0f dB, although its floors then require a planning margin. Neither PPO configuration became feasible (constrained PPO: %d of 50 runs). Two cooperating UAVs delivered %.2f times the sum rate at statistically indistinguishable EE, and a fairness weight traded up to %.0f%% of EE for a Jain index of %.2f. The IRS contribution depended on blockage, falling to %.1f%% with an unblocked direct link. This contributes a reproducible, like-for-like benchmark that shows where optimisation, learning and fleet scaling help, and under which channel conditions the IRS matters. Future work will build the planning margin into trajectory design, jointly re-optimise trajectories with the direct link, test larger constrained-RL agents, and validate on measured channels.' % (
    f('M1', 'EE', 1, 1e3), S['M1_vs_tour_pct'], sig_max, l_feas, sum_ratio, 100 * (1 - FR['2']['100.0']['EE'][0] / FR['2']['0.0']['EE'][0]), FR['2']['100.0']['jain'][0], DL['0']['IRS_gain_pct']))

''' + s[a1:]

# ---------------- Declarations
rep("supplied with this draft; ==[repository DOI to be added]==. No external dataset was used.')",
    "with fixed random seeds, and are available at ==[GitHub URL; Zenodo DOI]==. No external dataset was used.')")
rep("All results are generated by the simulation code (model, M1, M2, M3 and evaluation scripts) with fixed random seeds, with fixed random seeds,", "All results are generated by the simulation code (model, M1, M2, M3 and evaluation scripts) with fixed random seeds,")
rep("B.declaration('Use of AI tools.', 'The simulation code, analysis and first draft of this manuscript were produced with the assistance of Claude (Anthropic) under the authors\\' direction. ==[Authors to confirm and adapt to the target journal\\'s AI-use policy; all numbers should be re-run and verified by the authors.]==')",
    "B.declaration('Use of AI tools.', 'Claude (Anthropic) was used to assist with the simulation code, data analysis and drafting of this manuscript under the authors\\' direction. The authors reviewed the outputs and take full responsibility for the content.')")
rep("B.save('out/Energy_Aware_IRS_UAV_Manuscript.docx')", "B.save('out/Energy_Aware_IRS_UAV_Manuscript_rev1.docx')")
s = s.replace(chr(92)*2 + chr(39), chr(92) + chr(39))
open('build_paper_rev.py', 'w').write(s)
print('ok')
