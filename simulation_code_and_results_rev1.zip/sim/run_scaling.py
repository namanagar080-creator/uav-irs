"""M3 scaling study: K=8 users, fleet size U=1..4, plus coordinated-vs-uncoordinated ablation."""
import sys, pickle, time, warnings, numpy as np
warnings.filterwarnings('ignore')
import model as md, m3

seeds = range(int(sys.argv[1]) if len(sys.argv) > 1 else 5)
res = []
for s in seeds:
    u = md.make_users(s, K=8)
    for U in (1, 2, 3, 4):
        t = time.time()
        Q, S, m, fl = m3.run_m3(u, U, rng=np.random.default_rng(s))
        mu = m3.uncoordinated(u, U, Q, rng=np.random.default_rng(s)) if U > 1 else None
        keep = lambda d: {k: v for k, v in d.items() if k not in ('rho',)}
        res.append(dict(seed=s, U=U, m=keep(m), unc=keep(mu) if mu else None, Q=Q, users=u, time=time.time() - t))
        print('seed', s, 'U', U, 'EE %.0f sum %.2fM min %.2fM jain %.2f it %d  t=%.0fs' % (m['EE'], m['sum_rate'] / 1e6, m['min_rate'] / 1e6, m['jain'], m['iters'], time.time() - t), flush=True)
        pickle.dump(res, open('out/scaling.pkl', 'wb'))
