"""Fix #5: M1 multi-start spread (nominal NN-tour init vs 5 random-order tour inits) on the 10 layouts."""
import json, pickle, numpy as np, warnings, sys
warnings.filterwarnings('ignore')
import model as md, m1
from multiprocessing import Pool

def job(s):
    u = md.make_users(s, K=6); rng = np.random.default_rng(500 + s)
    out = []
    q, rho, m = m1.run_m1(u)           # nominal init
    out.append((m['EE'], bool(m['rmin_ok'])))
    for k in range(5):
        order = rng.permutation(len(u))
        wp = np.vstack([md.DEPOT] + [u[j] for j in order] + [md.DEPOT])
        seg = np.linalg.norm(np.diff(wp, axis=0), axis=1); sc = np.concatenate([[0], np.cumsum(seg)])
        tt = np.linspace(0, sc[-1], md.P['N'] + 1)[1:]
        q0 = np.stack([np.interp(tt, sc, wp[:, 0]), np.interp(tt, sc, wp[:, 1])], 1)
        if (np.linalg.norm(np.diff(np.vstack([md.DEPOT, q0]), axis=0), axis=1) > md.P['Vmax'] * md.P['delta']).any():
            continue
        q, rho, m = m1.run_m1(u, q_init=q0)
        out.append((m['EE'], bool(m['rmin_ok'])))
    return s, out

if __name__ == '__main__':
    with Pool(int(sys.argv[1]) if len(sys.argv) > 1 else 1) as p:
        res = p.map(job, range(10))
    json.dump(res, open('out/multistart.json', 'w'))
    for s, o in res:
        ee = [x[0] for x in o]; print(s, 'nominal %.0f best %.0f worst %.0f n=%d' % (ee[0], max(ee), min(ee), len(ee)))
