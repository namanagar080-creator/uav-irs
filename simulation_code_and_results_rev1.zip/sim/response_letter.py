import json, numpy as np
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

M2L = [json.load(open('out/m2L_s%d.json' % k)) for k in range(5)]
ee = np.array([np.mean([a['EE'] for a in m['after']]) for m in M2L]) / 1e3
feas = sum(sum(a['rmin_ok'] for a in m['after']) for m in M2L)
mr = np.array([np.mean([a['min_rate'] for a in m['after']]) for m in M2L]) / 1e6
RB = json.load(open('out/robust.json')); RM = json.load(open('out/robust_margin.json'))
DL = json.load(open('out/directlink.json')); FR = json.load(open('out/fairness.json'))
MS = json.load(open('out/multistart.json')); S = json.load(open('out/summary.json'))
ms_best = sum(1 for _, o in MS if o[0][0] >= max(x[0] for x in o) - 1e-6)
ms_gap = max(100 * (1 - o[0][0] / max(x[0] for x in o)) for _, o in MS)
ph = S['phase']

d = Document()
st = d.styles['Normal']; st.font.name = 'Times New Roman'; st.font.size = Pt(11)
for s in d.sections: s.left_margin = s.right_margin = Cm(2.2)
h = d.add_paragraph(); r = h.add_run('Response to second-level (minor) corrections'); r.bold = True; r.font.size = Pt(15); r.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
d.add_paragraph('Manuscript: "Energy-Efficient UAV-Mounted IRS Communication: Alternating Optimisation, Deep Reinforcement Learning and Multi-UAV Scheduling Compared" (revision 1).')
d.add_paragraph('We thank the reviewer for the careful first-principles check. Each must-fix item is answered below; new results come from the same code and seeds as the original submission. Section, table and figure numbers refer to the revised manuscript.')

items = [
 ('1. Make M2 a fair baseline (≥5 seeds, Lagrangian/constrained PPO), or reframe the claim.',
  'Done, and the claim is reframed. We implemented a Lagrangian-constrained PPO with a learned multiplier (dual ascent on the demand shortfall, Eq. 8) and trained it from five seeds (4,000 updates each) on top of the behaviour-cloning warm start. Results are in the new Section 4.4, Table 7, Table 3 and Figure 4. The multiplier reached its cap in all five runs. The least-served user\'s rate rose to %.3f Mbps on average (penalty agent: %.3f Mbps; floor: 0.4 Mbps), but only %d of 50 test runs met the floor, and EE fell to %.1f ± %.1f kbit/J. Because no PPO configuration became feasible, the abstract, Discussion and Conclusion now state that the comparison characterises the PPO set-ups tested, not a limit of (constrained) reinforcement learning. The abstract now says explicitly that neither PPO agent was feasible.' % (mr.mean(), S['M2']['min_rate'][0] / 1e6, feas, ee.mean(), ee.std(ddof=1))),
 ('2. Fill placeholder declarations, add the public repository, complete refs [18]/[19].',
  'Partly done; the rest needs the authors. Refs [18] and [19] are complete: Hu et al., Sci. Rep. 15: 9124 (2025), and Wang et al., Veh. Commun. 55: 100953 (2025), DOI 10.1016/j.vehcom.2025.100953. The Table 1 caveat and the "numbers should be re-run" note have been removed, and the AI-use statement is now a standard declaration. The code package now has a README with exact reproduction commands and a requirements file, ready for GitHub and a Zenodo DOI. Still highlighted for the authors: names, affiliations, e-mail, ORCID, acknowledgements, funding, conflict of interest, CRediT contributions, and the repository URL/DOI (Data availability).'),
 ('3. Imperfect CSI and IRS reconfiguration/estimation overhead.',
  'Done (Section 4.5, Figure 7). The scheduler or policy sees log-normal gain-estimation errors (σ = 0–8 dB); every user served in a slot costs τ = 0–100 ms of airtime. M1 kept the highest EE at every error level (%.1f → %.1f kbit/J at 8 dB), and the PPO agents did not overtake it. However, M1 lost feasibility already at σ = 2 dB (least-served user at %.0f%% of demand), because its schedule meets the floor with zero margin; the tour baseline behaved alike. A 10%% planning margin cost %.0f%% EE and restored feasibility for τ ≤ 50 ms and in %.0f%% of runs at σ = 2 dB. Larger margins need trajectory re-design, which we state as a limitation and future work. Learning did not overtake optimisation here, but we note that only estimation error, not structural model mismatch, was tested.' % (
      RB['sigma']['0']['M1']['EE'] / 1e3, RB['sigma']['8']['M1']['EE'] / 1e3, 100 * RB['sigma']['2']['M1']['minratio'], 100 * (1 - RM['0.1']['sigma_0']['EE'] / S['M1']['EE'][0]), 100 * RM['0.1']['sigma_2']['feas'])),
 ('4. Restore the direct BS-user link or justify full blockage.',
  'Done (Section 4.5, Table 8, Figure 7 right). We added a direct path with 3GPP UMa-NLoS path loss and an extra blockage loss L_b, combined coherently with the IRS path. This materially qualifies the paper: IRS phase control raises EE by %.0f%% when the direct path is blocked, %.0f%% at L_b = 20 dB, %.0f%% at 10 dB and only %.1f%% with no extra blockage. The text (Sections 3.1, 4.5, 5, abstract and conclusion) now states that the IRS gains apply to strongly blocked direct paths only.' % (DL['None']['IRS_gain_pct'], DL['20']['IRS_gain_pct'], DL['10']['IRS_gain_pct'], DL['0']['IRS_gain_pct'])),
 ('5. Optimality gap or bound for M1/M3.',
  'Done for M1 by multi-start (Section 4.5): six starts per layout (60 runs, all feasible). The nominal initialisation was best in %d of 10 layouts and at most %.1f%% below the best elsewhere, whereas random starts were up to 20%% worse. We describe this as sensitivity to initialisation, not a certificate of global optimality. M3 was not multi-started, which is listed as a limitation.' % (ms_best, ms_gap)),
 ('6. Fix 6.9 % vs 7.2 %; fairness-aware M3 or discuss the EE-fairness trade-off.',
  'On the percentage, we respectfully keep 6.9 %%. From the unrounded means (29.84 and 32.06 kbit/J) the loss is (32.06 − 29.84)/32.06 = %.2f %%; 7.2 %% arises from the rounded values 29.8 and 32.1. The unrounded means are now printed next to the figure. On fairness, we added a fairness weight w_f to the M3 scheduling LP (Section 3.3, Table 6). At U = 2, w_f = 100 raises Jain\'s index from %.2f to %.2f and the minimum rate from %.2f to %.2f Mbps at a %.0f%% EE cost, and intermediate weights trace the trade-off.' % (
      100 * (1 - ph['M1_bits_2'][0] / ph['M1_bits_None'][0]), FR['2']['0.0']['jain'][0], FR['2']['100.0']['jain'][0], FR['2']['0.0']['min_rate'][0] / 1e6, FR['2']['100.0']['min_rate'][0] / 1e6, 100 * (1 - FR['2']['100.0']['EE'][0] / FR['2']['0.0']['EE'][0]))),
]
for q, a in items:
    p = d.add_paragraph(); rr = p.add_run(q); rr.bold = True; rr.font.color.rgb = RGBColor(0x2F, 0x4F, 0x7F)
    p.paragraph_format.space_before = Pt(10)
    p2 = d.add_paragraph(); p2.add_run('Response: ').bold = True; p2.add_run(a)
    p2.paragraph_format.alignment = 3
p = d.add_paragraph(); p.paragraph_format.space_before = Pt(10)
p.add_run('Other changes. ').bold = True
p.add_run('The abstract is shortened to 237 words. Four sensitivity analyses are described in Section 3.4, and the limitations list is updated. The manuscript grows from 6 to 7 figures and from 5 to 8 tables, and the 30 references are unchanged in scope.')
d.save('out/Response_to_Corrections.docx')
print('ok')
